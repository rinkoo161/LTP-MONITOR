# LTP Monitor — Roadmap

Living list of pending work. Update this file as items are picked up,
completed, or reprioritized — it's the source of truth across sessions,
not the chat history.

## Newly added (2026-07-22)

- [x] **Persist open positions/spreads to disk, survive restarts/updates.**
  ~~Currently `positions` and `spreads` live only in the in-memory `Bus.state`~~
  Done: `open_state.json` snapshot (atomic write) saved on every
  positions/spreads mutation via a `Bus.set()` hook — catches every
  existing call site automatically, no per-call-site changes needed.
  Restored on `Orchestrator.__init__`, same pattern as closed-trade
  history. Missing/corrupt snapshot loads cleanly as empty rather than
  crashing startup. Tested: round-trip save/restore, position removal
  correctly drops from the snapshot on close, missing/corrupt file
  handling, full Orchestrator startup restore.

- [x] **Capital/margin used per trade + top-of-dashboard capital summary.**
  Done: `positions`/`spreads` now carry `capital_used`/`margin_used` at
  open time, shown as a column in all three positions/spreads tables
  (Dashboard, P&L/Orders, Strategy Library). New capital strip below the
  header shows **Total Capital**, **Capital Used**, **Capital
  Remaining**, and **Day P&L (incl. spreads)** — the P&L figure combines
  today's realized (closed trades) with live unrealized P&L from every
  currently-open position and spread. Backed by
  `sizing.deployed_capital()` (already existed) plus a new `capital`
  block in `Orchestrator.status()`. Tested end-to-end through the actual
  `/api/autopilot/status` response.

## Newly added (2026-07-22, continued)

- [x] **Macro/News relevance filtering + risk/opportunity scoring.**
  Fixed unparenthesized OR queries (bare "guidance"/"merger"/"India"
  matching anything) plus a post-fetch word-boundary relevance check.
  Each macro event now gets a bullish/bearish/neutral read, labeled
  Opportunity/Risk against the active symbol's regime direction instead
  of a flat Info label.
- [x] **ATR-based stoploss + trailing stop.** Alternative to fixed-%
  mode, using the regime engine's atr_pct. Preserves the exact rr=2.0
  ratio for PA strategies regardless of ATR reading so it can't get
  silently rejected by the risk-reward gate.
- [x] **Risk Management panel (partial).** Daily profit target (locks
  in gains, halts new positions for the day), transaction-level
  absolute-rupee SL/target, rupee-based step-ratchet trailing for
  single-leg positions (mirrors the spread ratchet). All exposed in a
  restructured Settings page.
- [x] **Settings page restructured** — the "Trading" card was a 30+
  field wall; split into 6 grouped subcards (Basics, Position Sizing,
  Stop-Loss & Trailing, Risk Management, Spread Management, News Gates)
  in a 2-column inner grid.
- [ ] **"Overall Strategy Level" SL/Target** from the reference image —
  not implemented (shown disabled in the reference too, lower priority).

## Newly added (2026-07-23) — Dhan Live Market Feed websocket

- [x] **Client built** — `dhan_ws.py`, wrapping the official `dhanhq`
  PyPI package's `MarketFeed` class (not hand-rolled binary parsing —
  Dhan's feed is well-documented and the library is first-party, so
  this carries none of the protocol-decoding risk the Kotak websocket
  work had). Built by installing the actual package and reading its
  `marketfeed.py` source directly, not guessing from docs — the
  response dict field names (LTP, OI, security_id, depth, etc.) are
  copied straight from `process_full()`/`process_quote()`.
- [x] **Chain-merge logic** — `merge_tick_into_chain()` updates a
  REST-fetched `chain:{symbol}` dict in place from a live tick, WITHOUT
  wiping REST-only fields the feed doesn't carry (iv, delta/theta/
  gamma/vega) — those stay as last known from the REST snapshot.
- [x] **Dependencies confirmed**: `dhanhq>=2.2.0` added to
  requirements.txt — pulls in `pandas`, `pyOpenSSL`, `websockets`
  (asyncio; distinct from `websocket-client` used by the Kotak client,
  no conflict). This is a real footprint increase (pandas especially)
  worth being aware of.
- [x] **Config toggle** — `market_data_feed`: `"rest"` (default) or
  `"websocket"`. Nothing switches automatically.
- [x] **Tested**: all internal logic that doesn't require a live Dhan
  connection — segment mapping (NIFTY/BANKNIFTY/FINNIFTY→NSE_FNO,
  SENSEX→BSE_FNO), tick parsing, packet-type filtering, unregistered-
  security_id handling, chain-merge correctness (incl. REST-only field
  preservation) — all verified with mocks.
- [x] **Tested against a real Dhan account (2026-07-23) — PASSED, both
  the option leg AND the index, after one round of fixing.** First run:
  NIFTY option leg (23850 CE) streamed correct real-time LTP (147.5),
  OI (3,479,775), and bid/ask (146.55/147.2) within seconds — this is
  the data the whole system actually needs, confirmed working end to
  end. The index (`add_index_instrument`) initially produced zero
  ticks — root cause: it was subscribing in Full mode, whose payload
  includes market depth + OI, neither of which exist for an index (no
  order book, no open interest, since an index isn't directly traded).
  Switched to Ticker mode (LTP+LTT only). Re-tested live: **both the
  index (LTP 23869.6) and the option leg now stream correctly.**
- [x] **Index security_ids double-checked against user-provided values**
  (NIFTY=13, BANKNIFTY=25, FINNIFTY=27, SENSEX=51) — already matched
  exactly in both `dhan_ws.py` and `broker_adapter.py`, no changes
  needed.
- [x] **Design review of Dhan's remaining data-API surface (2026-07-23)**
  — full writeup in `dhan_ws.py`'s module docstring. Summary:
  - **Option Chain / Historical Data**: REST-only by Dhan's own design
    (no websocket variant exists for either) — already correctly used
    via `broker_adapter.py`, unaffected by this work. The right
    architecture is exactly what's built: REST for the slower-changing
    shape (strikes, IV, greeks), this websocket overlaying fast fields
    (LTP/OI/depth) on top.
  - **Full Market Depth (20/200-level, a separate websocket)** —
    deliberately NOT built. Dhan's docs state only NSE Equity/
    Derivatives are enabled, excluding BSE — meaning SENSEX would have
    no depth coverage while the other three symbols would, breaking
    the same-logic-across-all-four-symbols design this app is built
    on. Also, current strategies price off best bid/ask (already in
    the 5-level depth this Live Feed already provides) and don't
    consume deep-book data. Worth revisiting only if a future strategy
    specifically needs it.
  - **Futures** — this system trades options only; no futures
    position/P&L/strategy exists anywhere in the codebase, and Dhan's
    option-chain endpoint doesn't return futures contracts (would need
    a separate scrip-master CSV lookup by `UNDERLYING_SECURITY_ID` +
    `INSTRUMENT=FUTIDX`). This is a strategy-level decision to make
    explicitly, not a data-plumbing gap — flagged rather than built
    speculatively.
- [x] **Wired into the live agent loop as a true hybrid (2026-07-24).**
  `MarketDataAgent` now has `_ensure_ws_client()`/`_sync_ws_feed()`/
  `_on_ws_tick()`. REST stays the ONLY source of chain shape/greeks —
  nothing about the existing REST cycle changed. When
  `market_data_feed` is `"websocket"` (Settings → Broker; default
  remains `"rest"`, zero behavior change unless explicitly opted in):
  a `DhanWebsocketClient` is created once, subscribes all 4 indices in
  Ticker mode immediately, and as each REST poll discovers option-leg
  `security_id`s, they're incrementally added via `subscribe_more()` —
  so the websocket subscription set grows to match whatever REST has
  already confirmed exists, never ahead of it. Ticks merge onto the
  same `chain:{symbol}` dict via `merge_tick_into_chain()` (option
  legs) or a direct spot/ticker update (index).
  Found and fixed a real race condition while wiring this: `subscribe_
  more()` can be called before the async websocket connection is fully
  up, and `MarketFeed.subscribe_symbols()` silently drops (not queues)
  a request made too early — with no error. Added `is_connected()`
  (tracked via on_connect/on_close) and made `subscribe_more()` return
  True/False; `MarketDataAgent` only marks a leg "subscribed" in its
  own bookkeeping if the send actually happened, so a too-early attempt
  correctly retries on the next ~3s cycle instead of being silently
  lost forever.
  Tested end-to-end with mocks: hybrid mode off → zero websocket
  activity (confirmed no client ever created); hybrid mode on → client
  created on first cycle, option legs correctly NOT marked subscribed
  before connection confirmed, correctly subscribed once connected,
  index tick correctly updates chain spot + ticker in place, option
  tick correctly merges LTP/OI/bid/ask. NOT yet run live in this
  wired-in form — the underlying pieces (`dhan_ws.py` itself) are
  live-validated, but this specific integration point needs a live
  market-hours run to confirm before relying on it for real trading.

## Still pending — roadmap items 6, 7, 9, 11, 12

- [ ] #6 — Chart.js visual pass / TradingView Lightweight Charts
- [ ] #7 / #12 — ML probability scoring
- [x] #9 — **Trade quality dashboard** — DONE. New `/api/quality`
  endpoint + "Trade Quality" nav page: expectancy per trade, profit
  factor, win rate, avg win/loss, and exit efficiency (% of each
  trade's peak MFE actually captured — directly measures the
  "giving back gains" pattern). Breakdowns by setup (orb/vwap/ema_mtf/
  spread strategies), by symbol, and by entry hour-of-day (with an
  inline net-P&L bar chart). Date + symbol filterable.
- [ ] #6 — Chart.js visual pass / TradingView Lightweight Charts
- [ ] #7 / #12 — ML probability scoring
- [ ] #11 — Liquidity-sweep / FVG confluence on the OI-wall logic



- [ ] **#6 — Chart.js visual pass / TradingView Lightweight Charts.** Not started.
- [ ] **#7 / #12 — ML probability scoring.** Shadow journal is accumulating
  real volume now; getting closer to viable but not started.
- [ ] **#9 — Trade quality dashboard** — expectancy, win rate by hour/setup,
  exit efficiency. Depends on MAE/MFE tracking (done) as a base.
- [ ] **#11 — Liquidity-sweep / FVG confluence** layered onto the existing
  OI-wall logic. Not started.
- [ ] **#13 (partial) — Full visual redesign, Supabase-docs style.**
  Done so far: color tokens, flat icons, panel headers, metric-card style,
  Settings page grouped/2-column layout, journal date filtering. Still
  open: deeper Supabase layout patterns beyond Settings, and an emoji
  cleanup pass across Dashboard/P&L/Strategies/Backtest/Agents panel
  headers (only the panels directly touched so far have been cleaned up).

## Recently completed (for context, not action items)

- Margin-aware position sizing, spread defense rules, MAE/MFE tracking,
  target/trail-stop retuning (items 1–4 of the original roadmap).
- News/Macro Agent (global markets + macro/news checkpoints, structured
  event log, provider error surfacing for Alpha Vantage/Twelve Data).
- News agent risk/opportunity scoring (roadmap #8) — replaced the old
  blanket block window with directional, decaying scoring.
- Bug fixes: spread sizing hard-zeroing instead of falling back to
  minimum lot; backtest replaying today's in-progress day as if closed;
  repeating/stale news alerts; substring keyword false-positives (e.g.
  "war" matching inside "Warner"); multi-timeframe confluence reading
  stale prior-day candles early in the session; cross-symbol signal
  staleness in the manual "Confirm & place order" flow.
