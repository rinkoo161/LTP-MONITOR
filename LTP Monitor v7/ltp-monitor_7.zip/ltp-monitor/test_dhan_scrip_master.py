"""test_dhan_scrip_master.py — validate futures lookup logic, first
against a constructed sample matching the documented schema (works
with no network), then against the REAL live scrip master CSV (needs
network — this sandbox can't reach images.dhan.co directly, so this
part has only been run against the constructed sample so far).

    python test_dhan_scrip_master.py

What "success" looks like:
  [1] constructed-sample test correctly picks the nearest UNEXPIRED
      contract (built with dates relative to today, not hardcoded
      absolute dates — so this is correct regardless of what day you
      actually run it)
  [2] the "pick nearest unexpired" logic correctly ignores an already-
      expired contract and a same-symbol option row mixed into the
      sample
  [3] live CSV download + parse succeeds and finds a real current-month
      contract for NIFTY/BANKNIFTY/FINNIFTY/SENSEX

If [3] fails with a "CSV schema mismatch" error: the printed fieldnames
list is the important part — paste it back so the column-name
resolution in dhan_scrip_master.py's COLUMN_CANDIDATES can be corrected
for whichever names the real file actually uses.
"""
import sys
from datetime import datetime, timedelta

import dhan_scrip_master as dsm

REPORT = []


def log(msg):
    print(msg)
    REPORT.append(msg)


def _build_sample_csv():
    """Dates relative to today, not hardcoded — a contract expiring
    "next week" should always be picked over one expiring "in 2
    months" or one that already expired "last week", regardless of
    what actual calendar date this test runs on.

    Schema and one row (FINNIFTY, security_id 61091) match the user's
    REAL confirmed compact scrip master data exactly, format "DD/MM/YY
    HH:MM":
      NSE, D, 61091, FUT, FUTIDX, 0, FINNIFTY-Jul2026-FUT, 60,
      FINNIFTY JUL FUT, 28/07/26 14:30
    """
    now = datetime.now()
    near = (now + timedelta(days=7)).strftime("%d/%m/%y %H:%M")   # current month
    mid = (now + timedelta(days=35)).strftime("%d/%m/%y %H:%M")   # next month
    far = (now + timedelta(days=63)).strftime("%d/%m/%y %H:%M")   # month after
    expired = (now - timedelta(days=7)).strftime("%d/%m/%y %H:%M")  # already gone
    header = ("SEM_EXM_EXCH_ID,SEM_SEGMENT,SEM_SMST_SECURITY_ID,"
             "SEM_EXCH_INSTRUMENT_TYPE,SEM_INSTRUMENT_NAME,SEM_EXPIRY_CODE,"
             "SEM_TRADING_SYMBOL,SEM_LOT_UNITS,SEM_CUSTOM_SYMBOL,"
             "SEM_EXPIRY_DATE,SEM_STRIKE_PRICE,SEM_OPTION_TYPE,"
             "SEM_TICK_SIZE,SEM_EXPIRY_FLAG,SEM_SERIES,SM_SYMBOL_NAME")
    rows = [
        # BANKNIFTY futures: near/mid/far/expired — near should win
        f"NSE,D,61088,FUT,FUTIDX,0,BANKNIFTY-Jul2026-FUT,35,BANKNIFTY JUL FUT,{near},0,,0.05,,,BANKNIFTY",
        f"NSE,D,58067,FUT,FUTIDX,0,BANKNIFTY-Aug2026-FUT,35,BANKNIFTY AUG FUT,{mid},0,,0.05,,,BANKNIFTY",
        f"NSE,D,68390,FUT,FUTIDX,0,BANKNIFTY-Sep2026-FUT,35,BANKNIFTY SEP FUT,{far},0,,0.05,,,BANKNIFTY",
        f"NSE,D,50001,FUT,FUTIDX,0,BANKNIFTY-Jun2026-FUT,35,BANKNIFTY JUN FUT,{expired},0,,0.05,,,BANKNIFTY",
        # NIFTY: one OPTIDX row (must be excluded) + one FUTIDX row (must win)
        f"NSE,D,90001,OPT,OPTIDX,0,NIFTY-Jul2026-24000-CE,75,NIFTY 24000 CE,{near},24000,CE,0.05,,,NIFTY",
        f"NSE,D,61093,FUT,FUTIDX,0,NIFTY-Jul2026-FUT,75,NIFTY JUL FUT,{near},0,,0.05,,,NIFTY",
        # Your exact confirmed real sample row (FINNIFTY, security_id 61091)
        f"NSE,D,61091,FUT,FUTIDX,0,FINNIFTY-Jul2026-FUT,60,FINNIFTY JUL FUT,{near},0,,0.05,,,FINNIFTY",
    ]
    return header + "\n" + "\n".join(rows) + "\n"


SAMPLE_CSV = _build_sample_csv()


def main():
    log("[1] Testing against a constructed sample matching your example row...")
    result, detail = dsm.get_current_future_detailed("BANKNIFTY", csv_text=SAMPLE_CSV)
    log(f"    result: {result}")
    log(f"    detail: {detail}")
    if not result:
        log("[1] FAIL — could not parse the constructed sample at all. "
           "This means the parsing logic itself has a bug (not a live-CSV "
           "schema issue, since this sample is hand-built to match the "
           "documented columns exactly).")
        sys.exit(1)

    checks = [
        ("security_id matches the nearest-unexpired contract (61088, "
         "the ~7-days-out one, correctly preferred over the 35/63-days-out "
         "and already-expired ones)", result["security_id"] == "61088"),
        ("symbol_name matches (BANKNIFTY-Jul2026-FUT)",
         result["symbol_name"] == "BANKNIFTY-Jul2026-FUT"),
        ("display_name matches (BANKNIFTY JUL FUT)",
         result["display_name"] == "BANKNIFTY JUL FUT"),
        ("did NOT pick the already-expired contract (50001, ~7 days ago)",
         result["security_id"] != "50001"),
        ("did NOT pick a farther-out contract just because it's listed "
         "later in the file (58067/68390 are 35/63 days out)",
         result["security_id"] not in ("58067", "68390")),
        ("exactly 3 unexpired candidates found (near/mid/far), expired "
         "one correctly excluded", detail.get("candidates_found") == 3),
    ]
    all_pass = True
    for desc, ok in checks:
        log(f"    {'PASS' if ok else 'FAIL'}: {desc}")
        all_pass = all_pass and ok
    log(f"[1] {'ALL PASS' if all_pass else 'SOME FAILED'}")

    log("")
    log("[2] Testing that a same-underlying OPTION row (OPTIDX) doesn't "
       "get picked up as a future...")
    # the sample includes a NIFTY OPTIDX row deliberately mixed in with
    # a NIFTY FUTIDX row to confirm the instrument-type filter works
    result2, detail2 = dsm.get_current_future_detailed("NIFTY", csv_text=SAMPLE_CSV)
    ok2 = result2 and result2["security_id"] == "61093"
    log(f"    {'PASS' if ok2 else 'FAIL'}: NIFTY future correctly resolved "
       f"to security_id 61093 (the FUTIDX row), not the OPTIDX row — got "
       f"{result2}")

    log("")
    log("[2b] Testing against YOUR exact confirmed real row "
       "(FINNIFTY, security_id 61091)...")
    result2b, detail2b = dsm.get_current_future_detailed("FINNIFTY", csv_text=SAMPLE_CSV)
    ok2b = (result2b and result2b["security_id"] == "61091"
           and result2b["symbol_name"] == "FINNIFTY-Jul2026-FUT"
           and result2b["lot_size"] == "60")
    log(f"    {'PASS' if ok2b else 'FAIL'}: your exact confirmed row parses "
       f"correctly — got {result2b}")

    log("")
    log("[2c] Testing the empty-SM_SYMBOL_NAME live bug (found 2026-07-24 "
       "in production: FINNIFTY/NIFTY/BANKNIFTY all failed with "
       "'sample underlying_symbol values seen: [\"\"]')...")
    now_plus_7 = (__import__("datetime").datetime.now() +
                 __import__("datetime").timedelta(days=7)).strftime("%d/%m/%y %H:%M")
    empty_symbol_csv = (
        "SEM_EXM_EXCH_ID,SEM_SEGMENT,SEM_SMST_SECURITY_ID,SEM_EXCH_INSTRUMENT_TYPE,"
        "SEM_INSTRUMENT_NAME,SEM_EXPIRY_CODE,SEM_TRADING_SYMBOL,SEM_LOT_UNITS,"
        "SEM_CUSTOM_SYMBOL,SEM_EXPIRY_DATE,SEM_STRIKE_PRICE,SEM_OPTION_TYPE,"
        "SEM_TICK_SIZE,SEM_EXPIRY_FLAG,SEM_SERIES,SM_SYMBOL_NAME\n"
        f"NSE,D,61091,FUT,FUTIDX,0,FINNIFTY-Jul2026-FUT,60,FINNIFTY JUL FUT,"
        f"{now_plus_7},0,,0.05,,,\n"   # SM_SYMBOL_NAME deliberately empty
    )
    result2c, detail2c = dsm.get_current_future_detailed("FINNIFTY", csv_text=empty_symbol_csv)
    ok2c = result2c and result2c["security_id"] == "61091"
    log(f"    {'PASS' if ok2c else 'FAIL'}: resolves via SEM_TRADING_SYMBOL "
       f"fallback when SM_SYMBOL_NAME is empty — got {result2c}")

    log("")
    log("[3] Attempting the REAL live scrip master CSV (needs network)...")
    try:
        real_result, real_detail = dsm.get_current_future_detailed("NIFTY")
        if real_result:
            log(f"    NIFTY current future: {real_result}")
            log("[3] PASS — live CSV fetched and parsed successfully")
        else:
            log(f"    [3] FAIL: {real_detail}")
            if "fieldnames" in str(real_detail):
                log("    ^ paste the fieldnames list back — that tells us "
                   "exactly which column names to add to COLUMN_CANDIDATES")
    except Exception as e:
        log(f"    [3] Could not even attempt this: {e}")

    log("")
    log("=" * 60)
    log("Paste this full output back for the next iteration.")


if __name__ == "__main__":
    main()
