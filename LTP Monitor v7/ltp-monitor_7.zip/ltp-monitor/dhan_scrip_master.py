"""dhan_scrip_master.py — futures instrument lookup via Dhan's scrip
master CSV.

Options don't need this: broker_adapter.py's option_chain() already
returns security_id per strike/leg directly from Dhan's Option Chain
REST endpoint. Futures are different — Dhan's option-chain endpoint
does not return futures contracts at all, and there's no "futures
chain" API. The scrip master CSV is the only way to find a futures
contract's security_id, and unlike option legs (looked up fresh every
REST poll), futures security_ids are effectively permanent-per-month:
a NEW security_id is generated for each new month's contract, and the
old one simply stops being current once it expires — there is no way
to compute a future month's security_id from a formula, it has to be
looked up.

Design: rather than hardcode security_ids (which would go stale every
month — exactly the problem this module exists to avoid), this
downloads Dhan's scrip master CSV, filters to FUTIDX rows for a given
underlying, and picks whichever unexpired contract has the NEAREST
expiry — i.e. "current month" is always computed dynamically from the
expiry dates themselves, so it self-updates through every monthly
rollover with no manual security-ID maintenance.

SCHEMA CONFIRMED 2026-07-23 with real column names and a real sample
row directly from the user (not guessed from docs):
  SEM_EXM_EXCH_ID  SEM_SEGMENT  SEM_SMST_SECURITY_ID
  SEM_EXCH_INSTRUMENT_TYPE  SEM_INSTRUMENT_NAME  SEM_EXPIRY_CODE
  SEM_TRADING_SYMBOL  SEM_LOT_UNITS  SEM_CUSTOM_SYMBOL  SEM_EXPIRY_DATE
  SEM_STRIKE_PRICE  SEM_OPTION_TYPE  SEM_TICK_SIZE  SEM_EXPIRY_FLAG
  SEM_SERIES  SM_SYMBOL_NAME
Sample row: NSE, D, 61091, FUT, FUTIDX, 0, FINNIFTY-Jul2026-FUT, 60,
  FINNIFTY JUL FUT, 28/07/26 14:30
This resolves what was previously an open question in this module:
  - This is the COMPACT file (api-scrip-master.csv, ~25MB, 200,000+
    rows across all instruments) — NOT api-scrip-master-detailed.csv,
    which this module previously (incorrectly) pointed at.
  - Security ID column is confirmed SEM_SMST_SECURITY_ID (matches an
    existing comment in broker_adapter.py from earlier research).
  - There is NO underlying-symbol column in this file at all (unlike
    the detailed CSV, which reportedly has one) — SM_SYMBOL_NAME is
    the closest match (confirmed "FINNIFTY" in the sample), used as
    the underlying-symbol filter instead.
  - Expiry date format is "DD/MM/YY HH:MM" (confirmed: "28/07/26
    14:30"), not "YYYY-MM-DD" as previously assumed.

REMAINING HONEST STATUS: this sandbox's egress allowlist still blocks
images.dhan.co directly (confirmed via `curl -I` → 403 host_not_allowed),
so this parsing logic is validated against a sample built from the
user's exact confirmed row — not a live download. The schema itself is
no longer a guess, but the full-file behavior (200,000+ rows, real
network conditions, whether SM_SYMBOL_NAME is ALWAYS a clean bare
symbol with no other rows matching ambiguously) still needs a live run
of test_dhan_scrip_master.py to fully confirm.
"""
import csv
import io
import os
import time
import urllib.request
from datetime import datetime, timedelta, timezone

IST = timezone(timedelta(hours=5, minutes=30))
STORE_DIR = os.path.expanduser("~/.ltp-monitor")
CACHE_PATH = os.path.join(STORE_DIR, "scrip_master.csv")
CACHE_TTL_HOURS = 20   # refresh roughly daily — this file is large (25MB,
                       # 200,000+ rows) and doesn't change intraday;
                       # new-month contracts appear well ahead of expiry

# Confirmed 2026-07-23: this is the COMPACT file, not -detailed.csv —
# the column schema above (SEM_* names, no UNDERLYING_SYMBOL) is what
# this specific file actually has.
SCRIP_MASTER_URL = "https://images.dhan.co/api-data/api-scrip-master.csv"

# Same exchange convention already established in broker_adapter.py's
# UNDERLYINGS dict — NIFTY/BANKNIFTY/FINNIFTY/MIDCPNIFTY futures trade
# on NSE; SENSEX futures trade on BSE. The user's example data covered
# NSE names only (BANKNIFTY/FINNIFTY/MIDCPNIFTY/NIFTY/NIFTYNXT50) —
# SENSEX was NOT in that list, and needs its own EXCH_ID=BSE query,
# flagged here rather than silently assumed to work the same way.
SYMBOL_EXCHANGE = {
    "NIFTY": ("NSE",), "BANKNIFTY": ("NSE",), "FINNIFTY": ("NSE",),
    "MIDCPNIFTY": ("NSE",), "NIFTYNXT50": ("NSE",),
    # Bug found live 2026-07-25: SENSEX spot/options work fine (they go
    # through Dhan's own numeric exchange-segment enum in
    # broker_adapter.py — a completely different system from this
    # scrip master CSV's text exchange codes), but SENSEX futures came
    # back empty. That spot success never actually confirmed what the
    # CSV's text code for BSE derivatives is — it was still a guess.
    # Rather than guess once and risk being wrong again, try multiple
    # plausible candidates in order; the first one that yields any
    # exch_matches (per the staged diagnostics below) is used.
    "SENSEX": ("BSE", "BSE_FNO", "BFO"),
}

# Column name candidates tried in order. Confirmed compact-CSV names
# listed FIRST (per the user's real schema); the detailed-CSV names
# kept as fallbacks in case a different scrip master variant is ever
# used. NOTE: "underlying_symbol" now maps to SM_SYMBOL_NAME — the
# compact file has no dedicated UNDERLYING_SYMBOL column at all.
COLUMN_CANDIDATES = {
    "security_id": ("SEM_SMST_SECURITY_ID", "SECURITY_ID", "Security_ID"),
    "exch_id": ("SEM_EXM_EXCH_ID", "EXCH_ID"),
    "segment": ("SEM_SEGMENT", "SEGMENT"),
    "instrument": ("SEM_INSTRUMENT_NAME", "INSTRUMENT"),
    "instrument_type": ("SEM_EXCH_INSTRUMENT_TYPE", "INSTRUMENT_TYPE"),
    "underlying_symbol": ("SM_SYMBOL_NAME", "UNDERLYING_SYMBOL"),
    "symbol_name": ("SEM_TRADING_SYMBOL", "SYMBOL_NAME"),
    "display_name": ("SEM_CUSTOM_SYMBOL", "DISPLAY_NAME"),
    "expiry_date": ("SEM_EXPIRY_DATE", "SM_EXPIRY_DATE"),
    "lot_size": ("SEM_LOT_UNITS", "LOT_SIZE"),
}


def _resolve_columns(fieldnames):
    """Map our logical field names to whichever actual column name is
    present in this CSV — defends against compact-vs-detailed naming
    differences without guessing wrong silently."""
    fieldset = set(fieldnames or [])
    resolved = {}
    missing = []
    for logical, candidates in COLUMN_CANDIDATES.items():
        found = next((c for c in candidates if c in fieldset), None)
        if found:
            resolved[logical] = found
        else:
            missing.append(logical)
    return resolved, missing


def _parse_expiry(raw):
    """Confirmed format (2026-07-23, real sample row): "DD/MM/YY HH:MM"
    e.g. "28/07/26 14:30". Other formats kept as fallbacks in case a
    different scrip master variant is ever used."""
    if not raw:
        return None
    raw = raw.strip()
    for fmt in ("%d/%m/%y %H:%M", "%Y-%m-%d", "%d-%b-%Y", "%d/%m/%Y",
               "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(raw, fmt).replace(tzinfo=IST)
        except ValueError:
            continue
    return None


def fetch_csv_text(force=False):
    """Download (with a local daily cache) the detailed scrip master
    CSV. Returns the raw text. Raises on total failure (no cache and
    no network) rather than silently returning nothing — a caller
    needs to know this failed, not get an empty future list that
    looks like "no contract exists"."""
    os.makedirs(STORE_DIR, exist_ok=True)
    if not force and os.path.exists(CACHE_PATH):
        age_hours = (time.time() - os.path.getmtime(CACHE_PATH)) / 3600
        if age_hours < CACHE_TTL_HOURS:
            with open(CACHE_PATH, encoding="utf-8", errors="ignore") as f:
                return f.read()
    req = urllib.request.Request(
        SCRIP_MASTER_URL, headers={"User-Agent": "ltp-monitor/1.0"})
    # This is a large file (all NSE/BSE/MCX instruments) — Dhan's own
    # docs don't specify a rate limit for it, but it's fetched once a
    # day at most either way given the cache above.
    with urllib.request.urlopen(req, timeout=30) as resp:
        text = resp.read().decode("utf-8", errors="ignore")
    with open(CACHE_PATH, "w", encoding="utf-8") as f:
        f.write(text)
    return text


def get_current_future(symbol, csv_text=None):
    """Return the nearest-unexpired FUTIDX contract for `symbol`, e.g.
    {"security_id": "68390", "symbol_name": "BANKNIFTY-Sep2026-FUT",
    "display_name": "BANKNIFTY SEP FUT", "expiry": datetime(...),
    "lot_size": 35, "exchange": "NSE"}, or None if nothing matched
    (expired list, wrong symbol, or the CSV schema didn't resolve —
    check the returned error detail via get_current_future_detailed).

    "Current" is computed dynamically from expiry dates — this is
    what makes the monthly rollover automatic: no security_id is ever
    hardcoded, so a new contract appearing (or an old one expiring)
    is picked up on the next call with no code change needed.
    """
    result, _ = get_current_future_detailed(symbol, csv_text)
    return result


def _derive_underlying_symbol(row, cols):
    """SM_SYMBOL_NAME confirmed empty for live FUTIDX rows (2026-07-24
    — the staged diagnostics below caught this directly: symbol_matches
    was 0 with 'sample underlying_symbol values seen: ['']'). Falls
    back to parsing SEM_TRADING_SYMBOL's prefix before the first
    hyphen, which the user's own originally-confirmed sample row
    showed IS reliably populated: "FINNIFTY-Jul2026-FUT" for FINNIFTY,
    security_id 61091. Tries the direct column first in case it's
    populated for other instrument types (options, equities) even
    though it's empty for FUTIDX specifically."""
    direct = row.get(cols["underlying_symbol"], "").strip().upper()
    if direct:
        return direct
    trading_symbol = row.get(cols.get("symbol_name", ""), "").strip().upper()
    if trading_symbol and "-" in trading_symbol:
        return trading_symbol.split("-")[0]
    return ""


def get_current_future_detailed(symbol, csv_text=None):
    """Same as get_current_future() but also returns a diagnostic
    dict explaining what happened — used by the validation test so a
    failure is actionable instead of a bare None."""
    symbol = symbol.upper()
    exch_candidates = SYMBOL_EXCHANGE.get(symbol)
    if not exch_candidates:
        return None, {"error": f"no exchange mapping for symbol {symbol!r}"}

    if csv_text is None:
        try:
            csv_text = fetch_csv_text()
        except Exception as e:
            return None, {"error": f"failed to fetch scrip master: {e}"}

    reader = csv.DictReader(io.StringIO(csv_text))
    cols, missing = _resolve_columns(reader.fieldnames)
    required = ("security_id", "exch_id", "instrument", "underlying_symbol",
               "expiry_date")
    missing_required = [c for c in required if c in missing]
    if missing_required:
        return None, {"error": f"CSV schema mismatch — missing required "
                      f"columns: {missing_required} (found: "
                      f"{reader.fieldnames})"}

    # Materialized once so multiple exchange-code candidates can each
    # scan the same rows — csv.DictReader is a single-pass generator.
    rows = list(reader)
    now = datetime.now(IST)
    all_exch_seen = set()
    attempts = []

    for exch in exch_candidates:
        stage_counts = {"exch_matches": 0, "instrument_matches": 0, "symbol_matches": 0}
        sample_symbol_names = set()
        candidates = []
        for row in rows:
            row_exch = row.get(cols["exch_id"], "").strip().upper()
            if row_exch:
                all_exch_seen.add(row_exch)
            if row_exch != exch:
                continue
            stage_counts["exch_matches"] += 1
            if row.get(cols["instrument"], "").strip().upper() != "FUTIDX":
                continue
            stage_counts["instrument_matches"] += 1
            row_symbol = _derive_underlying_symbol(row, cols)
            if len(sample_symbol_names) < 15:
                sample_symbol_names.add(row_symbol)
            if row_symbol != symbol:
                continue
            stage_counts["symbol_matches"] += 1
            expiry = _parse_expiry(row.get(cols["expiry_date"], ""))
            if not expiry or expiry < now:
                continue   # already expired — not a candidate for "current"
            candidates.append((expiry, row))

        if candidates:
            candidates.sort(key=lambda t: t[0])
            expiry, row = candidates[0]
            return {
                "security_id": row.get(cols["security_id"]),
                "symbol_name": row.get(cols.get("symbol_name", ""), ""),
                "display_name": row.get(cols.get("display_name", ""), ""),
                "expiry": expiry,
                "lot_size": row.get(cols.get("lot_size", ""), ""),
                "exchange": exch,
            }, {"candidates_found": len(candidates), "exch_code_used": exch}
        attempts.append({"exch_tried": exch, "stage_counts": stage_counts,
                         "sample_symbol_names": sorted(sample_symbol_names)[:15]})

    # None of the candidate exchange codes worked — report everything
    # needed to fix SYMBOL_EXCHANGE directly, including every real
    # exchange code actually present in the file (2026-07-25: this is
    # exactly the ambiguity that made a single guess unreliable —
    # showing every code actually seen resolves it conclusively
    # instead of guessing a third time).
    diag = {
        "error": f"no unexpired FUTIDX contract found for {symbol} — "
                f"tried exchange codes {list(exch_candidates)}, none worked",
        "attempts": attempts,
        "all_exchange_codes_seen_in_file": sorted(all_exch_seen),
    }
    for a in attempts:
        if a["stage_counts"]["exch_matches"] == 0:
            continue
        if a["stage_counts"]["instrument_matches"] == 0:
            diag["likely_cause"] = (f"exchange {a['exch_tried']!r} has rows "
                                    f"but none with instrument=FUTIDX")
            break
        if a["stage_counts"]["symbol_matches"] == 0:
            diag["likely_cause"] = (f"exchange {a['exch_tried']!r} has FUTIDX "
                                    f"rows but none matched symbol {symbol!r} "
                                    f"— sample names seen: "
                                    f"{a['sample_symbol_names']}")
            break
    else:
        diag["likely_cause"] = (f"NONE of {list(exch_candidates)} matched any "
                                f"row at all — check "
                                f"all_exchange_codes_seen_in_file above for "
                                f"the actual code to add to SYMBOL_EXCHANGE")
    return None, diag
