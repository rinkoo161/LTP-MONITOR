"""dhan_scrip_master.py — futures instrument lookup via Dhan's scrip
master CSV.

Options don't need this: broker_adapter.py's option_chain() already
returns security_id per strike/leg directly from Dhan's Option Chain
REST endpoint. Futures are different — Dhan's option-chain endpoint
does not return futures contracts at all, and there's no "futures
chain" API. The scrip master CSV is the only way to find a futures
contract's security_id, and unlike option legs (looked up fresh every
REST poll), futures security_ids are effectively permanent-per-month:
a NEW security_id is generated for each new month's contract, and the
old one simply stops being current once it expires — there is no way
to compute a future month's security_id from a formula, it has to be
looked up.

Design: rather than hardcode security_ids (which would go stale every
month — exactly the problem this module exists to avoid), this
downloads Dhan's detailed scrip master CSV, filters to FUTIDX rows for
a given underlying, and picks whichever unexpired contract has the
NEAREST expiry — i.e. "current month" is always computed dynamically
from the expiry dates themselves, so it self-updates through every
monthly rollover with no manual security-ID maintenance.

HONEST STATUS: this sandbox's egress allowlist blocks images.dhan.co
directly (confirmed: `curl -I` returns 403 host_not_allowed), so this
module's CSV-parsing logic is built and tested against a CONSTRUCTED
sample matching (a) Dhan's documented column schema
(dhanhq.co/docs/v2/instruments/) and (b) the exact example row the
user provided (BANKNIFTY-Sep2026-FUT, security_id 68390, expiry
2026-09-24) — NOT against the live file. Two things specifically need
a live confirmation run (see test_dhan_scrip_master.py):
  1. The detailed CSV's actual security-ID column name. Dhan's docs
     don't enumerate it explicitly in the column table, but the intro
     paragraph confirms "This fetches list of instruments as CSV with
     Security ID and other important details" — an existing comment
     in broker_adapter.py (from earlier research on the COMPACT csv)
     names it `SEM_SMST_SECURITY_ID` there; the detailed csv likely
     uses a plainer `SECURITY_ID`, matching what the user's message
     described, but this resolves defensively across both names
     rather than assuming either is definitely right.
  2. SM_EXPIRY_DATE's exact date format (assumed "YYYY-MM-DD"; a
     couple of common alternates are tried as a fallback).
"""
import csv
import io
import os
import time
import urllib.request
from datetime import datetime, timedelta, timezone

IST = timezone(timedelta(hours=5, minutes=30))
STORE_DIR = os.path.expanduser("~/.ltp-monitor")
CACHE_PATH = os.path.join(STORE_DIR, "scrip_master_detailed.csv")
CACHE_TTL_HOURS = 20   # refresh roughly daily — this file is large and
                       # doesn't change intraday; new-month contracts
                       # appear well ahead of expiry, not same-day

SCRIP_MASTER_URL = "https://images.dhan.co/api-data/api-scrip-master-detailed.csv"

# Same exchange convention already established in broker_adapter.py's
# UNDERLYINGS dict — NIFTY/BANKNIFTY/FINNIFTY/MIDCPNIFTY futures trade
# on NSE; SENSEX futures trade on BSE. The user's example data covered
# NSE names only (BANKNIFTY/FINNIFTY/MIDCPNIFTY/NIFTY/NIFTYNXT50) —
# SENSEX was NOT in that list, and needs its own EXCH_ID=BSE query,
# flagged here rather than silently assumed to work the same way.
SYMBOL_EXCHANGE = {
    "NIFTY": "NSE", "BANKNIFTY": "NSE", "FINNIFTY": "NSE",
    "MIDCPNIFTY": "NSE", "NIFTYNXT50": "NSE",
    "SENSEX": "BSE",   # unconfirmed — no example row for this one
}

# Column name candidates tried in order — see HONEST STATUS above for
# why security_id specifically is uncertain.
COLUMN_CANDIDATES = {
    "security_id": ("SECURITY_ID", "SEM_SMST_SECURITY_ID", "Security_ID"),
    "exch_id": ("EXCH_ID", "SEM_EXM_EXCH_ID"),
    "segment": ("SEGMENT", "SEM_SEGMENT"),
    "instrument": ("INSTRUMENT", "SEM_INSTRUMENT_NAME"),
    "instrument_type": ("INSTRUMENT_TYPE", "SEM_EXCH_INSTRUMENT_TYPE"),
    "underlying_symbol": ("UNDERLYING_SYMBOL",),
    "symbol_name": ("SYMBOL_NAME", "SM_SYMBOL_NAME"),
    "display_name": ("DISPLAY_NAME", "SEM_CUSTOM_SYMBOL"),
    "expiry_date": ("SM_EXPIRY_DATE", "SEM_EXPIRY_DATE"),
    "lot_size": ("LOT_SIZE", "SEM_LOT_UNITS"),
}


def _resolve_columns(fieldnames):
    """Map our logical field names to whichever actual column name is
    present in this CSV — defends against compact-vs-detailed naming
    differences without guessing wrong silently."""
    fieldset = set(fieldnames or [])
    resolved = {}
    missing = []
    for logical, candidates in COLUMN_CANDIDATES.items():
        found = next((c for c in candidates if c in fieldset), None)
        if found:
            resolved[logical] = found
        else:
            missing.append(logical)
    return resolved, missing


def _parse_expiry(raw):
    """SM_EXPIRY_DATE format isn't documented precisely — try a few
    common ones rather than assuming."""
    if not raw:
        return None
    raw = raw.strip()
    for fmt in ("%Y-%m-%d", "%d-%b-%Y", "%d/%m/%Y", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(raw, fmt).replace(tzinfo=IST)
        except ValueError:
            continue
    return None


def fetch_csv_text(force=False):
    """Download (with a local daily cache) the detailed scrip master
    CSV. Returns the raw text. Raises on total failure (no cache and
    no network) rather than silently returning nothing — a caller
    needs to know this failed, not get an empty future list that
    looks like "no contract exists"."""
    os.makedirs(STORE_DIR, exist_ok=True)
    if not force and os.path.exists(CACHE_PATH):
        age_hours = (time.time() - os.path.getmtime(CACHE_PATH)) / 3600
        if age_hours < CACHE_TTL_HOURS:
            with open(CACHE_PATH, encoding="utf-8", errors="ignore") as f:
                return f.read()
    req = urllib.request.Request(
        SCRIP_MASTER_URL, headers={"User-Agent": "ltp-monitor/1.0"})
    # This is a large file (all NSE/BSE/MCX instruments) — Dhan's own
    # docs don't specify a rate limit for it, but it's fetched once a
    # day at most either way given the cache above.
    with urllib.request.urlopen(req, timeout=30) as resp:
        text = resp.read().decode("utf-8", errors="ignore")
    with open(CACHE_PATH, "w", encoding="utf-8") as f:
        f.write(text)
    return text


def get_current_future(symbol, csv_text=None):
    """Return the nearest-unexpired FUTIDX contract for `symbol`, e.g.
    {"security_id": "68390", "symbol_name": "BANKNIFTY-Sep2026-FUT",
    "display_name": "BANKNIFTY SEP FUT", "expiry": datetime(...),
    "lot_size": 35, "exchange": "NSE"}, or None if nothing matched
    (expired list, wrong symbol, or the CSV schema didn't resolve —
    check the returned error detail via get_current_future_detailed).

    "Current" is computed dynamically from expiry dates — this is
    what makes the monthly rollover automatic: no security_id is ever
    hardcoded, so a new contract appearing (or an old one expiring)
    is picked up on the next call with no code change needed.
    """
    result, _ = get_current_future_detailed(symbol, csv_text)
    return result


def get_current_future_detailed(symbol, csv_text=None):
    """Same as get_current_future() but also returns a diagnostic
    dict explaining what happened — used by the validation test so a
    failure is actionable instead of a bare None."""
    symbol = symbol.upper()
    exch = SYMBOL_EXCHANGE.get(symbol)
    if not exch:
        return None, {"error": f"no exchange mapping for symbol {symbol!r}"}

    if csv_text is None:
        try:
            csv_text = fetch_csv_text()
        except Exception as e:
            return None, {"error": f"failed to fetch scrip master: {e}"}

    reader = csv.DictReader(io.StringIO(csv_text))
    cols, missing = _resolve_columns(reader.fieldnames)
    required = ("security_id", "exch_id", "instrument", "underlying_symbol",
               "expiry_date")
    missing_required = [c for c in required if c in missing]
    if missing_required:
        return None, {"error": f"CSV schema mismatch — missing required "
                      f"columns: {missing_required} (found: "
                      f"{reader.fieldnames})"}

    now = datetime.now(IST)
    candidates = []
    for row in reader:
        if row.get(cols["exch_id"], "").strip().upper() != exch:
            continue
        if row.get(cols["instrument"], "").strip().upper() != "FUTIDX":
            continue
        if row.get(cols["underlying_symbol"], "").strip().upper() != symbol:
            continue
        expiry = _parse_expiry(row.get(cols["expiry_date"], ""))
        if not expiry or expiry < now:
            continue   # already expired — not a candidate for "current"
        candidates.append((expiry, row))

    if not candidates:
        return None, {"error": f"no unexpired FUTIDX contract found for "
                      f"{symbol} ({exch}) — check the CSV actually "
                      f"contains {exch} derivatives rows"}

    candidates.sort(key=lambda t: t[0])
    expiry, row = candidates[0]
    return {
        "security_id": row.get(cols["security_id"]),
        "symbol_name": row.get(cols.get("symbol_name", ""), ""),
        "display_name": row.get(cols.get("display_name", ""), ""),
        "expiry": expiry,
        "lot_size": row.get(cols.get("lot_size", ""), ""),
        "exchange": exch,
    }, {"candidates_found": len(candidates)}
