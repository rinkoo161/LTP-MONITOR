"""test_dhan_scrip_master.py — validate futures lookup logic, first
against a constructed sample matching the documented schema (works
with no network), then against the REAL live scrip master CSV (needs
network — this sandbox can't reach images.dhan.co directly, so this
part has only been run against the constructed sample so far).

    python test_dhan_scrip_master.py

What "success" looks like:
  [1] constructed-sample test correctly picks the nearest UNEXPIRED
      contract (built with dates relative to today, not hardcoded
      absolute dates — so this is correct regardless of what day you
      actually run it)
  [2] the "pick nearest unexpired" logic correctly ignores an already-
      expired contract and a same-symbol option row mixed into the
      sample
  [3] live CSV download + parse succeeds and finds a real current-month
      contract for NIFTY/BANKNIFTY/FINNIFTY/SENSEX

If [3] fails with a "CSV schema mismatch" error: the printed fieldnames
list is the important part — paste it back so the column-name
resolution in dhan_scrip_master.py's COLUMN_CANDIDATES can be corrected
for whichever names the real file actually uses.
"""
import sys
from datetime import datetime, timedelta

import dhan_scrip_master as dsm

REPORT = []


def log(msg):
    print(msg)
    REPORT.append(msg)


def _build_sample_csv():
    """Dates relative to today, not hardcoded — a contract expiring
    "next week" should always be picked over one expiring "in 2
    months" or one that already expired "last week", regardless of
    what actual calendar date this test runs on."""
    now = datetime.now()
    near = (now + timedelta(days=7)).strftime("%Y-%m-%d")     # current month
    mid = (now + timedelta(days=35)).strftime("%Y-%m-%d")     # next month
    far = (now + timedelta(days=63)).strftime("%Y-%m-%d")     # month after
    expired = (now - timedelta(days=7)).strftime("%Y-%m-%d")  # already gone
    header = ("EXCH_ID,SEGMENT,ISIN,INSTRUMENT,UNDERLYING_SECURITY_ID,"
             "UNDERLYING_SYMBOL,SYMBOL_NAME,DISPLAY_NAME,INSTRUMENT_TYPE,"
             "SERIES,LOT_SIZE,SM_EXPIRY_DATE,STRIKE_PRICE,OPTION_TYPE,"
             "SECURITY_ID")
    rows = [
        f"NSE,D,,FUTIDX,25,BANKNIFTY,BANKNIFTY-Jul2026-FUT,BANKNIFTY JUL FUT,FUT,,35,{near},0,,61088",
        f"NSE,D,,FUTIDX,25,BANKNIFTY,BANKNIFTY-Aug2026-FUT,BANKNIFTY AUG FUT,FUT,,35,{mid},0,,58067",
        f"NSE,D,,FUTIDX,25,BANKNIFTY,BANKNIFTY-Sep2026-FUT,BANKNIFTY SEP FUT,FUT,,35,{far},0,,68390",
        f"NSE,D,,FUTIDX,25,BANKNIFTY,BANKNIFTY-Jun2026-FUT,BANKNIFTY JUN FUT,FUT,,35,{expired},0,,50001",
        f"NSE,D,,OPTIDX,13,NIFTY,NIFTY-Jul2026-24000-CE,NIFTY 24000 CE,OPT,,75,{near},24000,CE,90001",
        f"NSE,D,,FUTIDX,13,NIFTY,NIFTY-Jul2026-FUT,NIFTY JUL FUT,FUT,,75,{near},0,,61093",
    ]
    return header + "\n" + "\n".join(rows) + "\n"


SAMPLE_CSV = _build_sample_csv()


def main():
    log("[1] Testing against a constructed sample matching your example row...")
    result, detail = dsm.get_current_future_detailed("BANKNIFTY", csv_text=SAMPLE_CSV)
    log(f"    result: {result}")
    log(f"    detail: {detail}")
    if not result:
        log("[1] FAIL — could not parse the constructed sample at all. "
           "This means the parsing logic itself has a bug (not a live-CSV "
           "schema issue, since this sample is hand-built to match the "
           "documented columns exactly).")
        sys.exit(1)

    checks = [
        ("security_id matches the nearest-unexpired contract (61088, "
         "the ~7-days-out one, correctly preferred over the 35/63-days-out "
         "and already-expired ones)", result["security_id"] == "61088"),
        ("symbol_name matches (BANKNIFTY-Jul2026-FUT)",
         result["symbol_name"] == "BANKNIFTY-Jul2026-FUT"),
        ("display_name matches (BANKNIFTY JUL FUT)",
         result["display_name"] == "BANKNIFTY JUL FUT"),
        ("did NOT pick the already-expired contract (50001, ~7 days ago)",
         result["security_id"] != "50001"),
        ("did NOT pick a farther-out contract just because it's listed "
         "later in the file (58067/68390 are 35/63 days out)",
         result["security_id"] not in ("58067", "68390")),
        ("exactly 3 unexpired candidates found (near/mid/far), expired "
         "one correctly excluded", detail.get("candidates_found") == 3),
    ]
    all_pass = True
    for desc, ok in checks:
        log(f"    {'PASS' if ok else 'FAIL'}: {desc}")
        all_pass = all_pass and ok
    log(f"[1] {'ALL PASS' if all_pass else 'SOME FAILED'}")

    log("")
    log("[2] Testing that a same-underlying OPTION row (OPTIDX) doesn't "
       "get picked up as a future...")
    # the sample includes a NIFTY OPTIDX row deliberately mixed in with
    # a NIFTY FUTIDX row to confirm the instrument-type filter works
    result2, detail2 = dsm.get_current_future_detailed("NIFTY", csv_text=SAMPLE_CSV)
    ok2 = result2 and result2["security_id"] == "61093"
    log(f"    {'PASS' if ok2 else 'FAIL'}: NIFTY future correctly resolved "
       f"to security_id 61093 (the FUTIDX row), not the OPTIDX row — got "
       f"{result2}")

    log("")
    log("[3] Attempting the REAL live scrip master CSV (needs network)...")
    try:
        real_result, real_detail = dsm.get_current_future_detailed("NIFTY")
        if real_result:
            log(f"    NIFTY current future: {real_result}")
            log("[3] PASS — live CSV fetched and parsed successfully")
        else:
            log(f"    [3] FAIL: {real_detail}")
            if "fieldnames" in str(real_detail):
                log("    ^ paste the fieldnames list back — that tells us "
                   "exactly which column names to add to COLUMN_CANDIDATES")
    except Exception as e:
        log(f"    [3] Could not even attempt this: {e}")

    log("")
    log("=" * 60)
    log("Paste this full output back for the next iteration.")


if __name__ == "__main__":
    main()
