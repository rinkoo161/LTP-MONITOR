# LTP Monitor — Roadmap

Living list of pending work. Update this file as items are picked up,
completed, or reprioritized — it's the source of truth across sessions,
not the chat history.

## rinkoo.docx (2026-07-23) — status of every deliverable requested

Reference docs saved to `docs/strategy-reference/` (rinkoo.docx,
future_and_options.pdf, triple_screen_setup.pdf,
check_list_for_3rd_wave_setup_.pdf) for this and future sessions.

### Done and tested

- [x] **Scrip master schema fix** — real confirmed compact-CSV schema
  wired into `dhan_scrip_master.py` (`SEM_SMST_SECURITY_ID` etc.,
  `DD/MM/YY HH:MM` expiry format, `SM_SYMBOL_NAME` as the underlying-
  symbol filter since this file has no dedicated `UNDERLYING_SYMBOL`
  column). Tested against the user's exact FINNIFTY row (security_id
  61091). Still not run against the real 25MB live file — this
  sandbox's egress allowlist blocks images.dhan.co directly (confirmed
  403) — `test_dhan_scrip_master.py` is ready for that run.
- [x] **ATR-based position sizing** (`sizing.size_by_atr_risk`) —
  matches the docx's worked example exactly: capital ₹10,00,000, ATR
  228.47 → SL buffer 342.7pts → risk/lot ₹8,567.50; 1% risk → 1 lot
  (0.86% actual), 2% risk → 2 lots (1.71% actual). Includes the
  options-delta scaling note (ATM option premium moves ~half the
  index-point distance).
- [x] **"MACD+Stoch Confluence" strategy — the first new strategy
  requested, built and wired to execute.** `mtf_confluence_strategy.py`
  implements the WRITTEN rule set from the docx (daily MACD above-zero
  uptick + weekly MACD turning up after being down + RSI(14)>40 +
  Stochastic bullish cross from oversold + price in upper Bollinger
  Band — all 5 mandatory; bearish is the exact mirror; futures OI
  buildup is supportive-only, boosts confidence but never blocks).
  `MTFConfluenceAgent` runs it every 15 min during market hours and
  fires real BUY_CE/BUY_PE signals into the standard risk pipeline —
  same capital gates, position caps, daily loss limit as every other
  strategy, no special exemption. Sized via `size_by_atr_risk` with
  delta=0.5 (options, not futures). Visible on the Strategies page
  (new MTF Confluence panel) and configurable in Settings (enable
  toggle, min confidence, max trades/day).
  Indicator math (MACD/RSI/Stochastic/Bollinger %B/ATR/weekly
  resampling) independently verified against known reference behavior
  — monotonic series, crossover detection, %B at band extremes — not
  just trusted from the file's own comments. Found and fixed a real
  bug during this verification: an unclamped ATR-scaled stop distance
  could exceed the entire option premium when ATR is large relative to
  that day's IV (produced a ₹0.05 stoploss on a ₹100 option in
  testing) — added a 10-60%-of-entry sanity clamp and re-verified
  against the exact failing case plus two edge cases (realistic ATR,
  zero ATR).
  **Scope note**: this implements the WRITTEN rule set from rinkoo.docx,
  not the more elaborate second Pine Script in that doc (pivot-based
  MACD/RSI/Stochastic divergence detection, Fibonacci-extension
  targets, a full weekly/daily/1H confluence table) — that stays a
  distinct, larger follow-up, listed below, not silently folded in.
  Regression: all touched files pass syntax + import checks, JS
  validates, settings round-trip via the actual API, all agents
  (14 total incl. this one) instantiate and cycle cleanly with no
  live broker connection (graceful degradation confirmed).

### Explicitly deferred (not built, tracked here rather than dropped)

- [ ] **Full "1H MTF Reversal Strategy" port** — the second Pine
  Script in rinkoo.docx: pivot-high/low based divergence detection
  across MACD/RSI/Stochastic, EMA5/13/26 1H cross with a weekly+daily
  context gate, Fibonacci-extension or nearest-support/resistance
  targets, and a live on-chart confluence table. Substantially larger
  than the first strategy — recommend as its own dedicated session
  once the first strategy has a day or two of live results to compare
  against.
- [x] **Futures OI as a live supportive signal — DONE (2026-07-24).**
  `MarketDataAgent` now subscribes the current-month future per symbol
  (via `dhan_scrip_master.get_current_future_detailed()` + the
  existing `DhanWebsocketClient.subscribe_more()`, re-checked once per
  trading day — this is what makes monthly rollover automatic: a new
  day's lookup naturally resolves to whichever contract is now
  nearest-unexpired, and if that's a different security_id than
  yesterday's, the new one gets subscribed with no manual update).
  Futures ticks are classified into long/short buildup by comparing
  LTP+OI against a same-day baseline (captured at the first tick of
  each trading day — buildup is a session-level read, not tick-to-tick
  noise) and written to `future_oi_trend:{symbol}` as exactly `"long"`
  / `"short"` / `None` — matching `mtf_confluence_strategy.evaluate()`'s
  `future_buildup` parameter exactly (verified by reading its literal
  string comparisons before writing this, not assumed — an earlier
  draft would have written `"long_buildup"`/`"short_buildup"` here,
  which would have silently never matched). Only the strict textbook
  buildup quadrants (price+OI both up = long, price down + OI up =
  short) feed the strategy signal; the other two quadrants (short
  covering, long unwinding) are real signals but a weaker/different
  read than what rinkoo.docx specifically asked for — reported on a
  separate `future_oi_quadrant:{symbol}` diagnostic key instead, so
  the strategy only ever sees the exact signal it was specified
  against.
  Tested: all 4 OI/price quadrants classify correctly, first-tick and
  new-day baseline reset, daily dedup (doesn't re-subscribe same day),
  monthly rollover (different resolved security_id on a later day
  triggers a fresh subscribe), connection-not-ready retries next cycle
  rather than giving up for the day, scrip-master lookup failure
  logged and handled without crashing, futures ticks confirmed routed
  away from the option-chain merge (a future's data doesn't belong in
  `chain:{symbol}`'s strike/ce/pe rows), and a full end-to-end test
  confirming the live bus value actually reaches
  `mtf_confluence_strategy.evaluate()`'s confidence calculation.
  Scope respected: no changes to ExecutionAgent's place/exit/
  exit_spread, RiskAgent.evaluate, or sizing.py — confirmed by
  inspecting MarketDataAgent's method list after the change (only new
  methods: `_ensure_futures_subscribed`, `_classify_future_tick`) and
  confirming `sizing.size_by_atr_risk` is unchanged.
  Still requires `market_data_feed: "websocket"` to be enabled
  (defaults to `"rest"`) and Dhan as the active broker — same
  precondition as the rest of the hybrid feed.
- [ ] **News as an active entry/exit input** — currently news only
  gates (blocks a conflicting-direction signal, or scores as a
  same-direction opportunity via `news_risk_opportunity()`). The docx
  asks for something more attentive: news severity actively feeding
  entry/exit decisions, not just a block/pass gate. Needs a concrete
  design — e.g., a severity-weighted score merged into a strategy's
  confidence the same way futures-OI buildup already is for MTF
  Confluence — before implementation, since "more attentive" is a
  design decision (how much should a severe news event move a
  decision?) as much as a coding task.
- [x] **DJI/Nasdaq/Crude/Gold/Silver/macro-event summary — DONE
  (2026-07-24).** `/api/macro/digest` endpoint + a "Digest" panel at
  the top of the Macro/News page, above the existing raw event log —
  exactly as scoped: no new data plumbing, reads the same
  `macro_market_data`/`macro_events` bus keys `/api/macro` already
  exposed, compressed into indices + commodities/FX values, major
  events from the last 24h, and event counts by category. Tested with
  populated bus data through the actual API layer (not just empty
  state).

## Newly added (2026-07-24, continued) — ema_mtf never fired: root cause found

Second live-log review, same session. User asked why ORB/vwap_pullback/
ema_mtf showed no signals — turned out ORB and vwap_pullback WERE
firing (2 ORB signals became real approved+taken trades; vwap_pullback
fired but hit risk-gate rejections on regime/confluence, not silent).
`ema_mtf` was the genuinely, permanently silent one — not a market-
conditions issue, a real structural bug.

- [x] **Bug: `ema_mtf` could never fire with its own default settings.**
  Root cause, found in two parts:
  1. `c15_today` (today's 15-minute candles) was computed in
     `MarketDataAgent`'s candle-fetch method but never included in the
     dict stored to `pa_candles:{symbol}` — only `c1`/`c5` were stored.
  2. `PriceActionAgent.cycle()` then called `pa.evaluate(name,
     pack["c1"], pack["c5"], None, ...)` — the 15-min candles argument
     was hardcoded to `None`, not read from `pack`.
  `ema_mtf`'s `mtf_confirm` (the DEFAULT parameter value) requires BOTH
  `c5` and `c15` present — with `c15` always `None`, it bailed at that
  check on every single call, permanently, completely independent of
  whether a genuine 5/13 EMA cross was happening on the 1-minute
  candles. Fixed both points.
  Tested rigorously: constructed synthetic candles producing a genuine,
  precisely-timed fresh EMA cross confirmed by trending 5m/15m data —
  confirmed it fires correctly with real `c15` data, then re-ran the
  IDENTICAL setup with only `c15=None` to directly reproduce the exact
  original bug (same cross, same confirmation data, only the missing
  argument differs) — confirming this precise mechanism was the root
  cause, not a coincidence. Also verified end-to-end through the real
  `PriceActionAgent.cycle()` wiring (not just the isolated strategy
  function), and confirmed with `backtester.is_live_enabled` mocked
  that this fires and publishes an actual signal.
- [x] **New: per-strategy `no_setup` diagnostic breakdown.** The
  existing skip-reason counter aggregated all three PA strategies
  (orb/vwap_pullback/ema_mtf) into one `no_setup` number — meaning it
  was structurally impossible to tell from the log which strategy was
  actually silent, which is exactly the question that got asked. Added
  a per-strategy breakdown alongside the existing aggregate (kept for
  backward compatibility), surfaced in both the live summary and the
  10-minute diagnostic breadcrumb. Tested: confirms each strategy's
  no-setup count is correctly attributed individually.

## Newly added (2026-07-24, continued) — live production log review

First real activity-log review from a live paper-trading session
(2026-07-24 market hours). Two real bugs found and fixed; two genuine
live-data gaps diagnosed with better tooling (not blindly guess-fixed,
since this sandbox can't reach the live scrip master to debug
directly); one dead feed flagged.

- [x] **Bug: "daily profit target reached" message nonsensical on a
  PASSING check.** `check()` logs its label on every call regardless
  of pass/fail (prefixed ✓/✗) — the message was hardcoded to always
  read as the failure case ("reached... locking in"), so a normal
  passing check (day P&L still under target) printed "✓ daily profit
  target reached (₹0 ≥ ₹50000)" — literally false arithmetic shown as
  if true. Fixed: message now correctly describes whichever state
  actually holds. Tested both states directly.
- [x] **Finding, not a bug: live spread profit-target is ~10%, not the
  18% default.** Reverse-engineered from 5 real closed-spread captures
  in the log — 4 of 5 landed within a few paise of a 10%-of-credit
  threshold (BANKNIFTY: captured 3.8 vs a 10% threshold of 3.785,
  essentially exact), not the 18% default set earlier this week. This
  means the user's saved config.json has an old/custom
  `spread_profit_target_pct` value that the code default can't
  override — the same "stale config survives a code-default change"
  pattern hit repeatedly this project (daily_loss_limit, news cooldown,
  etc.), now confirmed happening again for this specific key.
  **Deliberately not changed** — today's actual results at ~10% were
  all net-positive (5/5 closed spreads profitable, +₹2,882 combined),
  so overriding a live user setting that's currently working well
  based on a theoretical 18% recommendation would be presumptuous.
  Flagged to the user directly; their Settings page shows the true
  current value if they want to check/adjust it themselves.
- [x] **Futures OI lookup failing live for SENSEX and FINNIFTY** —
  exactly the risk flagged when this was built (SENSEX's "BSE"
  exchange code was explicitly noted as unconfirmed; FINNIFTY's
  monthly-only 2026 listing change was a known open question).
  Since this sandbox can't reach the live scrip master to debug
  directly, added STAGED diagnostics to
  `get_current_future_detailed()` instead of guessing a fix: it now
  reports which filter stage (exchange code / instrument tag /
  underlying-symbol name / all-expired) eliminated every candidate,
  and for a symbol-name mismatch specifically, lists the actual
  underlying_symbol values seen in the file. Tested against three
  constructed failure scenarios (wrong exchange code, symbol name
  variant, all-expired) — each correctly diagnosed with a distinct,
  actionable `likely_cause`. No `agents.py` change needed — the richer
  diagnostic dict flows through the existing log line automatically.
  Next SENSEX/FINNIFTY failure in the log will say specifically which
  stage failed, rather than just "no unexpired contract found."
- [ ] **Financial Express RSS feed confirmed dead** (`HTTP Error 410:
  Gone`) — this was the user's own provided URL, not one added
  speculatively. Error handling worked correctly (logged clearly,
  didn't crash, didn't block the other 3 Indian feeds or any global
  feed). Not silently swapped or removed — flagged for the user to
  either find an updated URL or remove it via the feed-management UI.

## Newly added (2026-07-24) — News agent merge + RSS engine

At the user's request: two previously-separate news pipelines
(NewsAgent's single Google-News RSS query for risk-gating, and
NewsMacroAgent's NewsAPI-based global_macro/constituent/weather
categories) were independently fetching and classifying overlapping
stories — the user's exact complaint was "picking similar information
again and again."

- [x] **`news_engine.py`** — new shared module, used by BOTH agents:
  - RSS 2.0 + Atom feed parsing (stdlib `xml.etree`, no new dependency)
  - Category classification into geopolitical / market / tech /
    business / economics / energy / mergers / banking / auto / weather
    / global-macro / other — tested against 10 sample headlines
    spanning every category, all correct
  - Bias classification (bullish/bearish/neutral) — re-verified against
    the two previously-found substring bugs ("war" inside "Warner",
    "rain" inside "Ukraine") to confirm neither recurs in the shared
    module
  - **Impact-window heuristic** (1m/5m/15m) — a documented,
    category+severity-keyword-based estimate of how long a headline is
    likely to matter, explicitly NOT a validated/backtested prediction
    model; a starting point meant to be refined against real outcomes,
    same discipline as the spread profit-target and ATR-stop-clamp
    tuning earlier in this project
  - **Cross-source, cross-agent deduplication** — the actual fix for
    the user's complaint. `is_duplicate()`/`log_tracked_event()` share
    module-level state across both agents (they're threads in the same
    process). Tested: the same story from two different sources is
    deduped; a reworded/different-punctuation version of the same
    story is still caught (normalized signature); a genuinely different
    story is never falsely deduped.
  - Feed source CRUD (add/delete/persist to `~/.ltp-monitor/
    news_feeds.json`) — tested including duplicate-id and delete-
    nonexistent error cases
  - `test_feed()` — validates a URL and returns an actionable
    pass/fail rather than a stack trace, tested against HTTP errors,
    network errors, and empty-feed cases
  - Default feeds: the user's 4 confirmed-working Indian sources
    (Moneycontrol, Economic Times, Financial Express, Business Line)
    plus 5 global feeds (CNBC World/Economy/Finance/Energy, Yahoo
    Finance). **HONEST STATUS**: this sandbox's egress allowlist
    blocks every news domain tested (same restriction hit with
    images.dhan.co earlier) — none of these URLs have been fetched
    live from this environment. The Indian feeds are the user's own
    confirmed sources; the global ones are widely-documented,
    long-standing RSS endpoints, not personally verified. Use
    `/api/news/feeds/test` (or the Test button on the Macro/News page)
    to validate each source from a machine that can actually reach
    these domains before relying on any of them.
- [x] **NewsAgent rewired** to pull from the shared RSS engine instead
  of one hardcoded query. Its exact bus contract (`sentiment`/
  `risk_event`/`flagged_ts`, read by `news_risk_opportunity()` in the
  live risk-gating pipeline) was verified byte-for-byte unchanged after
  the swap — that logic is close to live trading and was deliberately
  left untouched beyond the input source. The existing stale-headline
  dedup (a previously-fixed bug) was re-tested and confirmed still
  works with the new fetch source.
- [x] **NewsMacroAgent rewired** to check the shared dedup before
  logging a NewsAPI-sourced event. Tested end-to-end: fed it a story
  already logged by NewsAgent plus a genuinely new one, confirmed it
  correctly logged only the new story.
- [x] **New "News Tracker" table** on the Macro/News page — every
  item shown with source, description, category, market-impact
  indicator, impact window, action, and a valid/invalid flag, with
  category/region/valid-only filters. Backed by `/api/news/tracker`.
- [x] **RSS feed management UI**, same page — add/delete/test feed
  sources (name, URL, category, region, id), backed by
  `/api/news/feeds` (GET/POST/DELETE) and `/api/news/feeds/test`.
- Regression: found and fixed a real bug during the verification pass
  — an earlier edit had accidentally dropped the `async function
  loadQuality(){` declaration line when inserting the new news
  functions before it, which would have broken the entire Trade
  Quality page (JS syntax error). Caught by running `node -c` on the
  extracted script block before packaging, not after.
- [ ] **Not yet done**: a real relevance/spam filter for RSS-sourced
  items (currently `valid` just checks for a non-empty title — a
  genuine filter, e.g. requiring a category match or a minimum keyword
  density, is a natural next refinement); the impact-window heuristic
  has not been validated against real candle outcomes yet (by design —
  it's flagged as a first-pass model to tune later, not a finished one).

- [ ] **TradingView integration** — the user has explicitly noted this
  needs to support ANALYSIS, not just visualization, and that a paid
  license may be required (which they will arrange). Not started —
  correctly gated on that licensing decision rather than built as a
  placeholder/substitute (e.g. a native inline-SVG chart standing in
  for "TradingView integration" would misrepresent what was actually
  delivered). Once a license path is confirmed, this needs its own
  scoping pass: which TradingView product (Charting Library / Advanced
  Charts / Lightweight Charts) fits the "for analysis" requirement,
  and how it connects to this system's live signals.
- [ ] **Avadhut Sathe Triple Screen / 3rd Wave Setup checklists** —
  saved to `docs/strategy-reference/` as requested ("keep at project
  level and learning"). These are dense, chart-pattern-recognition-
  heavy systems (Elliott Wave 3rd-wave counting, Tide/Wave/Ripple
  multi-timeframe structure, candlestick pattern recognition, Fibonacci
  retracement/extension) — not scoped as strategies to build yet; kept
  here as reference material the user may want built out later.

## Newly added (2026-07-22)

- [x] **Persist open positions/spreads to disk, survive restarts/updates.**
  ~~Currently `positions` and `spreads` live only in the in-memory `Bus.state`~~
  Done: `open_state.json` snapshot (atomic write) saved on every
  positions/spreads mutation via a `Bus.set()` hook — catches every
  existing call site automatically, no per-call-site changes needed.
  Restored on `Orchestrator.__init__`, same pattern as closed-trade
  history. Missing/corrupt snapshot loads cleanly as empty rather than
  crashing startup. Tested: round-trip save/restore, position removal
  correctly drops from the snapshot on close, missing/corrupt file
  handling, full Orchestrator startup restore.

- [x] **Capital/margin used per trade + top-of-dashboard capital summary.**
  Done: `positions`/`spreads` now carry `capital_used`/`margin_used` at
  open time, shown as a column in all three positions/spreads tables
  (Dashboard, P&L/Orders, Strategy Library). New capital strip below the
  header shows **Total Capital**, **Capital Used**, **Capital
  Remaining**, and **Day P&L (incl. spreads)** — the P&L figure combines
  today's realized (closed trades) with live unrealized P&L from every
  currently-open position and spread. Backed by
  `sizing.deployed_capital()` (already existed) plus a new `capital`
  block in `Orchestrator.status()`. Tested end-to-end through the actual
  `/api/autopilot/status` response.

## Newly added (2026-07-22, continued)

- [x] **Macro/News relevance filtering + risk/opportunity scoring.**
  Fixed unparenthesized OR queries (bare "guidance"/"merger"/"India"
  matching anything) plus a post-fetch word-boundary relevance check.
  Each macro event now gets a bullish/bearish/neutral read, labeled
  Opportunity/Risk against the active symbol's regime direction instead
  of a flat Info label.
- [x] **ATR-based stoploss + trailing stop.** Alternative to fixed-%
  mode, using the regime engine's atr_pct. Preserves the exact rr=2.0
  ratio for PA strategies regardless of ATR reading so it can't get
  silently rejected by the risk-reward gate.
- [x] **Risk Management panel (partial).** Daily profit target (locks
  in gains, halts new positions for the day), transaction-level
  absolute-rupee SL/target, rupee-based step-ratchet trailing for
  single-leg positions (mirrors the spread ratchet). All exposed in a
  restructured Settings page.
- [x] **Settings page restructured** — the "Trading" card was a 30+
  field wall; split into 6 grouped subcards (Basics, Position Sizing,
  Stop-Loss & Trailing, Risk Management, Spread Management, News Gates)
  in a 2-column inner grid.
- [ ] **"Overall Strategy Level" SL/Target** from the reference image —
  not implemented (shown disabled in the reference too, lower priority).

## Newly added (2026-07-23) — Dhan Live Market Feed websocket

- [x] **Client built** — `dhan_ws.py`, wrapping the official `dhanhq`
  PyPI package's `MarketFeed` class (not hand-rolled binary parsing —
  Dhan's feed is well-documented and the library is first-party, so
  this carries none of the protocol-decoding risk the Kotak websocket
  work had). Built by installing the actual package and reading its
  `marketfeed.py` source directly, not guessing from docs — the
  response dict field names (LTP, OI, security_id, depth, etc.) are
  copied straight from `process_full()`/`process_quote()`.
- [x] **Chain-merge logic** — `merge_tick_into_chain()` updates a
  REST-fetched `chain:{symbol}` dict in place from a live tick, WITHOUT
  wiping REST-only fields the feed doesn't carry (iv, delta/theta/
  gamma/vega) — those stay as last known from the REST snapshot.
- [x] **Dependencies confirmed**: `dhanhq>=2.2.0` added to
  requirements.txt — pulls in `pandas`, `pyOpenSSL`, `websockets`
  (asyncio; distinct from `websocket-client` used by the Kotak client,
  no conflict). This is a real footprint increase (pandas especially)
  worth being aware of.
- [x] **Config toggle** — `market_data_feed`: `"rest"` (default) or
  `"websocket"`. Nothing switches automatically.
- [x] **Tested**: all internal logic that doesn't require a live Dhan
  connection — segment mapping (NIFTY/BANKNIFTY/FINNIFTY→NSE_FNO,
  SENSEX→BSE_FNO), tick parsing, packet-type filtering, unregistered-
  security_id handling, chain-merge correctness (incl. REST-only field
  preservation) — all verified with mocks.
- [x] **Tested against a real Dhan account (2026-07-23) — PASSED, both
  the option leg AND the index, after one round of fixing.** First run:
  NIFTY option leg (23850 CE) streamed correct real-time LTP (147.5),
  OI (3,479,775), and bid/ask (146.55/147.2) within seconds — this is
  the data the whole system actually needs, confirmed working end to
  end. The index (`add_index_instrument`) initially produced zero
  ticks — root cause: it was subscribing in Full mode, whose payload
  includes market depth + OI, neither of which exist for an index (no
  order book, no open interest, since an index isn't directly traded).
  Switched to Ticker mode (LTP+LTT only). Re-tested live: **both the
  index (LTP 23869.6) and the option leg now stream correctly.**
- [x] **Index security_ids double-checked against user-provided values**
  (NIFTY=13, BANKNIFTY=25, FINNIFTY=27, SENSEX=51) — already matched
  exactly in both `dhan_ws.py` and `broker_adapter.py`, no changes
  needed.
- [x] **Design review of Dhan's remaining data-API surface (2026-07-23)**
  — full writeup in `dhan_ws.py`'s module docstring. Summary:
  - **Option Chain / Historical Data**: REST-only by Dhan's own design
    (no websocket variant exists for either) — already correctly used
    via `broker_adapter.py`, unaffected by this work. The right
    architecture is exactly what's built: REST for the slower-changing
    shape (strikes, IV, greeks), this websocket overlaying fast fields
    (LTP/OI/depth) on top.
  - **Full Market Depth (20/200-level, a separate websocket)** —
    deliberately NOT built. Dhan's docs state only NSE Equity/
    Derivatives are enabled, excluding BSE — meaning SENSEX would have
    no depth coverage while the other three symbols would, breaking
    the same-logic-across-all-four-symbols design this app is built
    on. Also, current strategies price off best bid/ask (already in
    the 5-level depth this Live Feed already provides) and don't
    consume deep-book data. Worth revisiting only if a future strategy
    specifically needs it.
  - **Futures** — this system trades options only; no futures
    position/P&L/strategy exists anywhere in the codebase, and Dhan's
    option-chain endpoint doesn't return futures contracts (would need
    a separate scrip-master CSV lookup by `UNDERLYING_SECURITY_ID` +
    `INSTRUMENT=FUTIDX`). This is a strategy-level decision to make
    explicitly, not a data-plumbing gap — flagged rather than built
    speculatively.
- [x] **Wired into the live agent loop as a true hybrid (2026-07-24).**
  `MarketDataAgent` now has `_ensure_ws_client()`/`_sync_ws_feed()`/
  `_on_ws_tick()`. REST stays the ONLY source of chain shape/greeks —
  nothing about the existing REST cycle changed. When
  `market_data_feed` is `"websocket"` (Settings → Broker; default
  remains `"rest"`, zero behavior change unless explicitly opted in):
  a `DhanWebsocketClient` is created once, subscribes all 4 indices in
  Ticker mode immediately, and as each REST poll discovers option-leg
  `security_id`s, they're incrementally added via `subscribe_more()` —
  so the websocket subscription set grows to match whatever REST has
  already confirmed exists, never ahead of it. Ticks merge onto the
  same `chain:{symbol}` dict via `merge_tick_into_chain()` (option
  legs) or a direct spot/ticker update (index).
  Found and fixed a real race condition while wiring this: `subscribe_
  more()` can be called before the async websocket connection is fully
  up, and `MarketFeed.subscribe_symbols()` silently drops (not queues)
  a request made too early — with no error. Added `is_connected()`
  (tracked via on_connect/on_close) and made `subscribe_more()` return
  True/False; `MarketDataAgent` only marks a leg "subscribed" in its
  own bookkeeping if the send actually happened, so a too-early attempt
  correctly retries on the next ~3s cycle instead of being silently
  lost forever.
  Tested end-to-end with mocks: hybrid mode off → zero websocket
  activity (confirmed no client ever created); hybrid mode on → client
  created on first cycle, option legs correctly NOT marked subscribed
  before connection confirmed, correctly subscribed once connected,
  index tick correctly updates chain spot + ticker in place, option
  tick correctly merges LTP/OI/bid/ask. NOT yet run live in this
  wired-in form — the underlying pieces (`dhan_ws.py` itself) are
  live-validated, but this specific integration point needs a live
  market-hours run to confirm before relying on it for real trading.
- [x] **Futures data-plumbing added (2026-07-24)**, at your request with
  real scrip-master example data (BANKNIFTY-Sep2026-FUT, security_id
  68390) — but scoped as DATA ACCESS ONLY, not a new trading strategy.
  This system still trades options exclusively; nothing here opens a
  futures position or references futures P&L anywhere. What it does
  add: `dhan_scrip_master.py` downloads (daily-cached) Dhan's detailed
  scrip master CSV and resolves the CURRENT-MONTH futures contract for
  a symbol by picking whichever unexpired row has the nearest expiry —
  computed dynamically from expiry dates every time, so monthly
  rollover (a new security_id every month, no formula for it) is
  handled automatically with no manual maintenance. `dhan_ws.py` gained
  `add_future_instrument()` (Full mode — futures have real OI/depth,
  unlike the index) that either takes an explicit security_id or calls
  the scrip-master lookup itself.
  Tested: your exact example row (68390) resolves correctly; "nearest
  unexpired, not just listed last" logic verified with dates relative
  to today (not hardcoded, so this stays correct on any day it's run);
  an expired contract and a same-underlying OPTION row mixed into the
  sample are both correctly excluded; SENSEX correctly resolves to
  BSE_FNO (not NSE_FNO, unlike your example list which only covered
  NSE names); unknown symbols and scrip-master schema mismatches both
  fail with an actionable message rather than a crash.
  HONEST STATUS: `dhan_scrip_master.py`'s CSV parsing is validated
  against a constructed sample matching the documented schema — this
  sandbox's egress allowlist blocks images.dhan.co directly (confirmed:
  a direct `curl -I` returns 403), so it has NOT been run against the
  real live file. `test_dhan_scrip_master.py` is written and ready to
  validate that — if it reports a "CSV schema mismatch," the printed
  fieldnames list is what's needed to fix `COLUMN_CANDIDATES`.
  NOT wired into `MarketDataAgent`'s hybrid loop — that loop currently
  only handles index + option instruments. Wiring futures in is a
  reasonable next step once (a) the live CSV test passes and (b) there's
  an actual reason to want futures data flowing (e.g. as a spot proxy,
  or if a futures strategy gets added later) — flagging this as a
  decision point rather than building it speculatively.

## Pending roadmap items (not yet started) — published 2026-07-23

| # | Item | Status |
|---|------|--------|
| 6 | Chart.js visual pass / TradingView Lightweight Charts | Not started |
| 7 | ML scoring (shadow journal is accumulating volume now) | Not started |
| 9 | Trade quality dashboard — expectancy, win rate by hour/setup, exit efficiency | **Done** — `/api/quality` endpoint + Trade Quality nav page |
| 11 | Liquidity-sweep / FVG confluence layered onto OI-wall logic | Not started |
| 12 | ML probability scoring (same track as #7, larger scope) | Not started |
| 13 (partial) | Full visual redesign | Token/color/icon/Settings-layout/journal-filter pass done; charts, Dashboard/P&L/Strategies/Backtest/Agents panel emoji cleanup, and deeper Supabase layout patterns (breadcrumbs, page sections elsewhere) still open |

Detail on each:

- [ ] **#6 — Chart.js visual pass / TradingView Lightweight Charts.** Not
  started. Note: this is distinct from the TradingView-for-analysis
  requirement raised in rinkoo.docx (needs a licensing decision) — this
  item is purely visual/charting for existing dashboard panels.
- [ ] **#7 / #12 — ML probability scoring.** Shadow journal is
  accumulating real volume now; getting closer to viable but not
  started.
- [x] **#9 — Trade quality dashboard.** Done — `/api/quality` endpoint
  + "Trade Quality" nav page: expectancy per trade, profit factor, win
  rate, avg win/loss, exit efficiency (% of each trade's peak MFE
  actually captured). Breakdowns by setup, by symbol, by entry
  hour-of-day (inline net-P&L bar chart), plus MFE/MAE scatter charts
  (vs P&L and volume). Date + symbol filterable.
- [ ] **#11 — Liquidity-sweep / FVG confluence** layered onto the
  existing OI-wall logic. Not started.
- [ ] **#13 (partial) — Full visual redesign, Supabase-docs style.**
  Done so far: color tokens, flat icons, panel headers, metric-card
  style, Settings page grouped/2-column layout, journal date
  filtering. Still open: deeper Supabase layout patterns beyond
  Settings (breadcrumbs, page sections elsewhere), and an emoji
  cleanup pass across Dashboard/P&L/Strategies/Backtest/Agents panel
  headers (only the panels directly touched so far have been cleaned
  up).

## Recently completed (for context, not action items)

- Margin-aware position sizing, spread defense rules, MAE/MFE tracking,
  target/trail-stop retuning (items 1–4 of the original roadmap).
- News/Macro Agent (global markets + macro/news checkpoints, structured
  event log, provider error surfacing for Alpha Vantage/Twelve Data).
- News agent risk/opportunity scoring (roadmap #8) — replaced the old
  blanket block window with directional, decaying scoring.
- Bug fixes: spread sizing hard-zeroing instead of falling back to
  minimum lot; backtest replaying today's in-progress day as if closed;
  repeating/stale news alerts; substring keyword false-positives (e.g.
  "war" matching inside "Warner"); multi-timeframe confluence reading
  stale prior-day candles early in the session; cross-symbol signal
  staleness in the manual "Confirm & place order" flow.
