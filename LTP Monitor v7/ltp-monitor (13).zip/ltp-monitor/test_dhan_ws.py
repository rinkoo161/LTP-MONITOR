"""test_dhan_ws.py — validate the Dhan Live Market Feed websocket against
Dhan's REAL server before trusting it live. Run this FIRST, tonight,
with your real Dhan access token, and read the output carefully.

    python test_dhan_ws.py

What "success" looks like:
  [1] connects and receives an on_connect callback (not just a TCP connect)
  [2] subscribing to a NIFTY index-adjacent instrument or NIFTY option
      leg produces a real tick within ~15 seconds
  [3] the tick's LTP is a plausible number for that instrument (not 0,
      not NaN) and OI is present (non-None) for the option leg
  [4] merge_tick_into_chain() correctly updates a mock REST-shaped
      chain dict without touching its REST-only fields (iv/greeks)

This test needs your Dhan client_id + access_token in
~/.ltp-monitor/config.json (same keys the REST path already uses:
dhan_client_id, dhan_access_token) and the market to be open — Dhan's
feed won't produce ticks outside trading hours.

If [1] fails: check the access token hasn't expired (Dhan tokens are
short-lived, same as the REST path already handles) and that the
`dhanhq` package is actually installed (`pip install dhanhq`).

If [1]/[2] pass but [3] shows LTP=0 or OI=None: the connection/
subscription mechanics work but the specific security_id may be wrong,
or the market is closed. Not a protocol failure — paste this output
back so we can pin down which.
"""
import sys
import time

import config
import dhan_ws


REPORT = []


def log(msg):
    print(msg)
    REPORT.append(msg)


def main():
    cfg = config.load()
    client_id = cfg.get("dhan_client_id")
    access_token = cfg.get("dhan_access_token")
    if not client_id or not access_token:
        log("[SETUP] No dhan_client_id/dhan_access_token in config — "
            "add them via Settings first (same fields the REST path uses).")
        sys.exit(1)

    if dhan_ws.MarketFeed is None:
        log("[SETUP] dhanhq package not installed. Run: pip install dhanhq")
        sys.exit(1)

    log(f"[1] Building DhanWebsocketClient for client_id={client_id[:4]}...")
    ticks_received = []
    statuses = []

    def on_tick(sym, sec_id, tick):
        ticks_received.append((sym, sec_id, tick))
        log(f"    TICK  {sym} [{sec_id}] LTP={tick['ltp']} OI={tick['oi']} "
            f"bid={tick['bid']} ask={tick['ask']}")

    def on_status(msg):
        statuses.append(msg)
        log(f"    STATUS: {msg}")

    client = dhan_ws.DhanWebsocketClient(
        client_id, access_token, on_tick=on_tick, on_status=on_status,
        verbose=True)

    # NIFTY 50 index itself (IDX_I segment, security_id 13) is the
    # simplest possible instrument to validate the connection with —
    # no option-chain lookup needed, always trades when market is open.
    # NOTE: add_instrument() currently only maps NIFTY/BANKNIFTY/
    # FINNIFTY/SENSEX -> NSE_FNO/BSE_FNO for OPTION legs. For this
    # smoke test we subscribe a real NIFTY option security_id instead —
    # replace SAMPLE_SECURITY_ID below with a live one from today's
    # chain (check the dashboard's option chain panel, or the
    # ~/.ltp-monitor/history.db instruments table) before running.
    SAMPLE_SECURITY_ID = cfg.get("dhan_ws_test_security_id", "")
    if not SAMPLE_SECURITY_ID:
        log("[SETUP] No test security_id configured. Add "
            "\"dhan_ws_test_security_id\": \"<a real NIFTY option "
            "security_id from today's chain>\" to config.json, or edit "
            "this script directly, then re-run.")
        sys.exit(1)

    client.add_instrument("NIFTY", SAMPLE_SECURITY_ID)
    log(f"[2] Subscribing to NIFTY security_id={SAMPLE_SECURITY_ID}, "
       f"connecting...")
    client.start()

    log("[3] Waiting up to 20s for ticks (market must be open)...")
    for _ in range(20):
        time.sleep(1)
        if ticks_received:
            break

    if not statuses:
        log("[FAIL] No on_connect/on_status callback fired at all — "
            "check network/token before anything else.")
    elif not ticks_received:
        log("[PARTIAL] Connected but received zero ticks in 20s. Either "
           "the market is closed, the security_id is wrong/expired, or "
           "the subscription silently failed — check the STATUS lines "
           "above for an on_error message.")
    else:
        sym, sec_id, tick = ticks_received[-1]
        ok_ltp = tick["ltp"] and tick["ltp"] > 0
        ok_oi = tick["oi"] is not None
        log(f"[3] Got {len(ticks_received)} tick(s). Last: LTP={tick['ltp']} "
           f"({'OK' if ok_ltp else 'SUSPICIOUS — zero/missing'}), "
           f"OI={tick['oi']} ({'OK' if ok_oi else 'MISSING'})")

    client.stop()

    # [4] merge_tick_into_chain — pure function, no live connection needed
    log("[4] Testing merge_tick_into_chain() against a mock REST-shaped chain...")
    mock_chain = {
        "symbol": "NIFTY", "spot": 24000,
        "rows": [{"strike": 24000,
                  "ce": {"ltp": 100.0, "oi": 500, "iv": 15.2, "delta": 0.5,
                        "security_id": "12345"},
                  "pe": {"ltp": 90.0, "oi": 400, "iv": 14.8, "delta": -0.5,
                        "security_id": "12346"}}],
    }
    updated = dhan_ws.merge_tick_into_chain(
        mock_chain, "12345", {"ltp": 105.5, "oi": 520, "volume": 1000,
                              "bid": 105.0, "ask": 106.0})
    ce = mock_chain["rows"][0]["ce"]
    checks = [
        ("merge returned True", updated is True),
        ("ltp updated to 105.5", ce["ltp"] == 105.5),
        ("oi updated to 520", ce["oi"] == 520),
        ("iv (REST-only field) preserved at 15.2", ce["iv"] == 15.2),
        ("delta (REST-only field) preserved at 0.5", ce["delta"] == 0.5),
        ("pe leg untouched (ltp still 90.0)", mock_chain["rows"][0]["pe"]["ltp"] == 90.0),
    ]
    all_pass = True
    for desc, result in checks:
        log(f"    {'PASS' if result else 'FAIL'}: {desc}")
        all_pass = all_pass and result
    log(f"[4] merge_tick_into_chain: {'ALL PASS' if all_pass else 'SOME FAILED'}")

    log("")
    log("=" * 60)
    log("Paste this full output back for the next iteration.")


if __name__ == "__main__":
    main()
