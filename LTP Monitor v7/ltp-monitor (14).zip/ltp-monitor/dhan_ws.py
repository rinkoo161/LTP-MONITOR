"""dhan_ws.py — persistent Dhan Live Market Feed websocket client.

Wraps the OFFICIAL `dhanhq` package's MarketFeed class
(github.com/dhan-oss/DhanHQ-py, PyPI: dhanhq) rather than hand-rolling
the binary protocol — Dhan's feed is well-documented and the library is
first-party, so unlike the Kotak websocket (reverse-engineered from a
JS bundle) there is no protocol-decoding risk here.

Feeds live ticks into the same bus keys the REST polling path already
populates ("chain:{symbol}"), so every existing consumer (analyzer,
strategies, dashboard) works unchanged regardless of whether data
arrives via REST or websocket. See merge_tick_into_chain() below for
the exact field mapping — built directly from the leg schema in
broker_adapter.py's _leg() helper so REST-only fields (iv, delta,
theta, gamma, vega — the feed doesn't carry greeks) are preserved
across a websocket update rather than being wiped out.

HONEST STATUS: built by installing the actual `dhanhq` package
(v2.2.0) and reading its marketfeed.py source directly — the response
dict field names below (LTP, OI, security_id, exchange_segment, etc.)
are copied from process_full()/process_quote() in that file, not
guessed from documentation. This has NOT been run against a live Dhan
account/connection. Run test_dhan_ws.py FIRST with real credentials
and read its output before trusting this for live trading — same
validation discipline used for the Kotak websocket integration.

Dependencies (see requirements.txt): `dhanhq` pulls in pandas,
pyOpenSSL, and websockets (asyncio-based — a different package from
websocket-client, which the Kotak client uses; both coexist fine).
"""
import threading
import time

try:
    from dhanhq import DhanContext, MarketFeed
except ImportError:
    DhanContext = None
    MarketFeed = None

# Exchange segment constants (from the installed package's marketfeed.py —
# also matches the official DhanHQ v2 API annexure exactly):
#   IDX=0, NSE=1, NSE_FNO=2, NSE_CURR=3, BSE=4, MCX=5, BSE_CURR=7, BSE_FNO=8
# NIFTY/BANKNIFTY/FINNIFTY options trade on NSE_FNO; SENSEX options on
# BSE_FNO (SENSEX itself is a BSE index) — this mirrors UNDERLYINGS/segment
# handling already established in broker_adapter.py for the REST path.
SEGMENT_FOR_SYMBOL = {
    "NIFTY": "NSE_FNO", "BANKNIFTY": "NSE_FNO", "FINNIFTY": "NSE_FNO",
    "MIDCPNIFTY": "NSE_FNO", "SENSEX": "BSE_FNO",
}

# The underlying INDEX itself (not an option leg) — IDX_I segment,
# permanent security_ids that never expire/change, unlike option legs
# which are per-strike-per-expiry. Same values as UNDERLYINGS in
# broker_adapter.py. Useful for a zero-setup connectivity smoke test:
# no option-chain lookup needed, and the index always trades when the
# market is open, so a missing tick means a connection problem, not a
# stale/wrong strike.
INDEX_SECURITY_ID = {
    "NIFTY": "13", "BANKNIFTY": "25", "FINNIFTY": "27",
    "MIDCPNIFTY": "442", "SENSEX": "51",
}


class DhanWebsocketClient:
    """One persistent connection subscribed to a set of option-leg
    instruments (by security_id). Call add_instrument() for each strike
    leg you want live ticks for, then start() once.

    MarketFeed.start() already manages its own background thread and
    has an internal reconnect-on-drop loop (_run_async) — we don't need
    to reimplement that (unlike the Kotak client, which had to build
    reconnect/heartbeat by hand against a reverse-engineered protocol).
    We add only an outer error-cooldown so a persistently failing
    token/account doesn't spin retrying forever against Dhan's servers.
    """

    MAX_ERRORS_BEFORE_COOLDOWN = 5
    COOLDOWN_SECS = 300

    def __init__(self, client_id, access_token, on_tick=None, on_status=None,
                verbose=False):
        if MarketFeed is None:
            raise RuntimeError(
                "dhanhq package not installed — run: pip install dhanhq")
        self.on_tick = on_tick or (lambda sym, sec_id, tick: None)
        self.on_status = on_status or (lambda msg: None)
        self.verbose = verbose
        self._dhan_context = DhanContext(client_id, access_token)
        self._feed = None
        self._thread = None
        self._instruments = []      # [(segment_str, security_id_str), ...]
        self._sec_to_sym = {}       # int(security_id) -> our symbol name
        self._error_count = 0
        self._cooling_down = threading.Event()

    def add_instrument(self, symbol, security_id):
        """Register an option-leg security_id to subscribe to, in Full
        (LTP + OI + depth) mode. Call before start(); for a live
        connection use subscribe_more() instead."""
        segment = SEGMENT_FOR_SYMBOL.get(symbol.upper())
        if not segment:
            raise ValueError(f"no exchange segment mapping for symbol {symbol!r}")
        sid = str(security_id)
        self._instruments.append((segment, sid))
        self._sec_to_sym[int(security_id)] = symbol.upper()

    def add_index_instrument(self, symbol):
        """Subscribe to the underlying INDEX itself (IDX_I segment,
        permanent security_id — see INDEX_SECURITY_ID) rather than an
        option leg. No option-chain lookup needed; useful as a
        zero-setup connectivity smoke test since the index always
        trades when the market is open."""
        symbol = symbol.upper()
        sid = INDEX_SECURITY_ID.get(symbol)
        if not sid:
            raise ValueError(f"no index security_id known for symbol {symbol!r}")
        self._instruments.append(("IDX_I", sid))
        self._sec_to_sym[int(sid)] = symbol

    def start(self):
        """Connect and subscribe in a MarketFeed-managed background
        thread. Returns that thread (daemon=True, matches the Kotak
        client's start() contract)."""
        if not self._instruments:
            raise RuntimeError("no instruments added — call add_instrument() first")
        # MarketFeed wants (exchange_segment_enum_int, security_id, mode) —
        # but its own get_exchange_segment() maps int->string, and the
        # constructor stores our tuples as-is for validate_and_process_tuples,
        # which expects (exchange, instrument_id) where "exchange" is
        # whatever we pass through to get_exchange_segment(exchange_code) —
        # that function is only ever called with the INT segment codes
        # (0/1/2/...), so we must pass the int form, not the string.
        seg_int = {"NSE_FNO": MarketFeed.NSE_FNO, "BSE_FNO": MarketFeed.BSE_FNO,
                  "IDX_I": MarketFeed.IDX}
        instruments = [(seg_int[seg], sid, MarketFeed.Full)
                       for seg, sid in self._instruments]

        def _on_message(feed, data):
            self._handle_tick(data)

        def _on_error(feed, err):
            self._error_count += 1
            self.on_status(f"error: {err}")
            if self._error_count >= self.MAX_ERRORS_BEFORE_COOLDOWN:
                self.on_status(f"{self._error_count} errors — cooling down "
                              f"{self.COOLDOWN_SECS}s before further retries")
                self._cooling_down.set()
                time.sleep(self.COOLDOWN_SECS)
                self._error_count = 0
                self._cooling_down.clear()

        def _on_connect(feed):
            self._error_count = 0
            self.on_status(f"connected — {len(instruments)} instrument(s) subscribed")

        def _on_close(feed):
            self.on_status("connection closed")

        self._feed = MarketFeed(
            self._dhan_context, instruments, version="v2",
            on_connect=_on_connect, on_message=_on_message,
            on_close=_on_close, on_error=_on_error,
        )
        self._thread = self._feed.start()
        return self._thread

    def subscribe_more(self, symbol, security_id):
        """Add an instrument to an already-open connection."""
        segment = SEGMENT_FOR_SYMBOL.get(symbol.upper())
        if not segment or self._feed is None:
            return
        seg_int = {"NSE_FNO": MarketFeed.NSE_FNO, "BSE_FNO": MarketFeed.BSE_FNO}[segment]
        self._sec_to_sym[int(security_id)] = symbol.upper()
        self._feed.subscribe_symbols([(seg_int, str(security_id), MarketFeed.Full)])

    def stop(self):
        if self._feed:
            self._feed.close_connection()

    def _handle_tick(self, data):
        """data is the dict returned by MarketFeed.process_full() /
        process_quote() / process_ticker() — see marketfeed.py in the
        installed dhanhq package. We only act on Full Data packets
        (type == "Full Data"), which is what we subscribe in."""
        if not data or not isinstance(data, dict):
            return
        if data.get("type") not in ("Full Data", "Quote Data"):
            return   # ignore Ticker/OI/depth-only/status packets for now
        sec_id = data.get("security_id")
        sym = self._sec_to_sym.get(sec_id)
        if sym is None:
            return
        try:
            ltp = float(data.get("LTP", 0) or 0)
        except (TypeError, ValueError):
            return
        tick = {
            "security_id": sec_id,
            "ltp": ltp,
            "oi": data.get("OI"),
            "volume": data.get("volume"),
            "bid": None, "ask": None,   # populated below if depth present
        }
        depth = data.get("depth")
        if depth:
            # best bid/ask = first level of the 5-level depth array
            try:
                tick["bid"] = float(depth[0]["bid_price"])
                tick["ask"] = float(depth[0]["ask_price"])
            except (KeyError, IndexError, ValueError, TypeError):
                pass
        if self.verbose:
            self.on_status(f"{sym} [{sec_id}] LTP={tick['ltp']} OI={tick['oi']}")
        self.on_tick(sym, sec_id, tick)


def merge_tick_into_chain(chain, security_id, tick):
    """Update a REST-fetched `chain:{symbol}` dict in place with a live
    websocket tick, WITHOUT touching REST-only fields the feed doesn't
    carry (iv, delta/theta/gamma/vega, oi_chg needs previous_oi context
    the feed doesn't give us either — left untouched, only refreshed on
    the next REST snapshot).

    This is the integration point a future MarketDataAgent change would
    call from its tick-received callback; not yet wired into the live
    agent loop — see the module docstring's HONEST STATUS note.
    Returns True if a matching leg was found and updated, else False.
    """
    if not chain or not chain.get("rows"):
        return False
    for row in chain["rows"]:
        for leg_key in ("ce", "pe"):
            leg = row.get(leg_key)
            if leg and leg.get("security_id") == security_id:
                leg["ltp"] = tick["ltp"]
                if tick.get("oi") is not None:
                    leg["oi"] = tick["oi"]
                if tick.get("volume") is not None:
                    leg["volume"] = tick["volume"]
                if tick.get("bid") is not None:
                    leg["bid"] = tick["bid"]
                if tick.get("ask") is not None:
                    leg["ask"] = tick["ask"]
                return True
    return False
