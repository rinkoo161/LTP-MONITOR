"""
Autopilot: the automated analyse -> signal -> execute -> monitor -> exit loop.

Safety rails (deliberate, non-negotiable in this app):
  * PAPER MODE is the default -- orders are simulated until you turn it off
    in Settings.
  * AUTO-EXECUTE is a separate opt-in; with it off, autopilot generates
    signals and monitors, but every real order needs a click.
  * Hard cap on trades per day; single open position at a time.
  * Kill switch: stopping autopilot never leaves silent background orders.

Cycle (roughly every 45s while running):
  1. fetch chain -> analyzer
  2. no open position -> ask AI/rule engine for structured signal
     -> if BUY_* and confidence >= threshold -> execute (paper or live)
  3. open position -> track option LTP against SL/targets
     -> exit on SL hit, target2 hit, or spot invalidation
"""

import threading
import time
from collections import deque

import config
from analyzer import analyze, ai_signal


class Autopilot:
    def __init__(self, get_chain, orders_factory):
        self.get_chain = get_chain            # symbol -> chain dict
        self.orders_factory = orders_factory  # () -> DhanOrders | None
        self.log = deque(maxlen=300)
        self.running = False
        self.symbol = None
        self.position = None                  # open position dict
        self.trades_today = 0
        self.day = time.strftime("%Y-%m-%d")
        self.last_signal = None
        self._thread = None
        self._stop = threading.Event()

    # ------------------------------------------------------------- control
    def start(self, symbol: str):
        if self.running:
            return self.status()
        self.symbol = symbol.upper()
        self._stop.clear()
        self.running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        self._log(f"Autopilot started on {self.symbol} "
                  f"({'PAPER' if config.load()['paper_mode'] else 'LIVE'} mode)")
        return self.status()

    def stop(self):
        self._stop.set()
        self.running = False
        self._log("Autopilot stopped by user")
        return self.status()

    def status(self):
        cfg = config.load()
        return {
            "running": self.running,
            "symbol": self.symbol,
            "paper_mode": cfg["paper_mode"],
            "auto_execute": cfg["auto_execute"],
            "trades_today": self.trades_today,
            "max_trades_per_day": cfg["max_trades_per_day"],
            "position": self.position,
            "last_signal": self.last_signal,
            "log": list(self.log)[-40:],
        }

    # ------------------------------------------------------------- loop
    def _loop(self):
        while not self._stop.is_set():
            try:
                self._cycle()
            except Exception as e:
                self._log(f"⚠ cycle error: {e}")
            self._stop.wait(45 if not self.position else 20)

    def _cycle(self):
        today = time.strftime("%Y-%m-%d")
        if today != self.day:
            self.day, self.trades_today = today, 0

        chain = self.get_chain(self.symbol)
        analysis = analyze(chain)
        if analysis.get("error"):
            self._log("⚠ empty chain; skipping cycle")
            return

        if self.position:
            self._manage(analysis)
        else:
            self._hunt(analysis)

    def _hunt(self, analysis):
        cfg = config.load()
        if self.trades_today >= cfg["max_trades_per_day"]:
            return
        sig = ai_signal(analysis)
        self.last_signal = sig
        if sig["signal"] == "WAIT":
            self._log(f"Signal: WAIT ({sig['reasons'][0] if sig['reasons'] else ''})")
            return
        self._log(f"Signal: {sig['signal']} {sig['strike']} "
                  f"@₹{sig['entry']} SL ₹{sig['stoploss']} "
                  f"T1 ₹{sig['target1']} conf {sig['confidence']}% "
                  f"[{sig.get('source','')}]")
        if sig["confidence"] < cfg["min_confidence"]:
            self._log(f"…below confidence threshold {cfg['min_confidence']}%, not trading")
            return
        if not cfg["auto_execute"]:
            self._log("…auto-execute OFF: waiting for manual confirmation in dashboard")
            return
        self.execute(sig, analysis)

    def execute(self, sig: dict, analysis: dict, manual=False):
        """Enter a position (paper or live). Called by autopilot or by the
        dashboard's confirm button."""
        cfg = config.load()
        lot = cfg["lot_sizes"].get(self.symbol or analysis["symbol"], 75)
        qty = lot * cfg["lots_per_trade"]
        leg = "CE" if sig["signal"] == "BUY_CE" else "PE"
        label = f"{analysis['symbol']} {sig['strike']} {leg}"

        if cfg["paper_mode"]:
            fill = sig.get("option_ltp") or sig["entry"]
            self._log(f"📄 PAPER BUY {qty} x {label} @ ₹{fill}")
            order_id = f"PAPER-{int(time.time())}"
        else:
            orders = self.orders_factory()
            if orders is None:
                self._log("⚠ Dhan not configured; cannot place live order")
                return
            if not sig.get("security_id"):
                self._log("⚠ no security_id on signal; cannot place live order")
                return
            resp = orders.place(analysis["symbol"], sig["security_id"],
                                "BUY", qty, "MARKET")
            order_id = resp.get("orderId", "?")
            fill = sig.get("option_ltp") or sig["entry"]
            self._log(f"🔴 LIVE BUY {qty} x {label} — order {order_id}")

        self.position = {
            "symbol": analysis["symbol"], "strike": sig["strike"],
            "leg": leg, "qty": qty, "entry": fill,
            "stoploss": sig["stoploss"], "target1": sig["target1"],
            "target2": sig["target2"],
            "spot_invalidation": sig.get("spot_invalidation"),
            "security_id": sig.get("security_id"),
            "order_id": order_id, "opened": time.strftime("%H:%M:%S"),
            "ltp": fill, "pnl": 0.0, "t1_hit": False,
            "paper": cfg["paper_mode"], "manual": manual,
        }
        self.trades_today += 1

    def _manage(self, analysis):
        p = self.position
        leg = p["leg"].lower()
        row = next((s for s in analysis["strikes"]
                    if s["strike"] == p["strike"]), None)
        if not row:
            return
        ltp = row[leg]["ltp"]
        p["ltp"] = ltp
        p["pnl"] = round((ltp - p["entry"]) * p["qty"], 0)
        spot = analysis["spot"]

        exit_reason = None
        if ltp <= p["stoploss"]:
            exit_reason = f"stoploss hit (₹{ltp} ≤ ₹{p['stoploss']})"
        elif ltp >= p["target2"]:
            exit_reason = f"target-2 hit (₹{ltp})"
        elif p["t1_hit"] and ltp <= p["entry"]:
            exit_reason = "gave back gains after T1 — protecting capital"
        elif p.get("spot_invalidation"):
            inv = p["spot_invalidation"]
            if (p["leg"] == "CE" and spot < inv) or \
               (p["leg"] == "PE" and spot > inv):
                exit_reason = f"spot invalidation ({spot:.0f} vs {inv})"

        if not p["t1_hit"] and ltp >= p["target1"]:
            p["t1_hit"] = True
            p["stoploss"] = max(p["stoploss"], p["entry"])  # trail to breakeven
            self._log(f"✅ T1 hit at ₹{ltp} — SL trailed to breakeven ₹{p['stoploss']}")

        if exit_reason:
            self.exit_position(exit_reason)
        else:
            self._log(f"holding {p['strike']} {p['leg']} · LTP ₹{ltp} "
                      f"· P&L ₹{p['pnl']:.0f}")

    def exit_position(self, reason="manual exit"):
        p = self.position
        if not p:
            return {"error": "no open position"}
        cfg = config.load()
        if p["paper"]:
            self._log(f"📄 PAPER SELL {p['qty']} x {p['symbol']} {p['strike']} "
                      f"{p['leg']} @ ₹{p['ltp']} — {reason} · P&L ₹{p['pnl']:.0f}")
        else:
            orders = self.orders_factory()
            if orders and p.get("security_id"):
                try:
                    resp = orders.place(p["symbol"], p["security_id"],
                                        "SELL", p["qty"], "MARKET")
                    self._log(f"🔴 LIVE SELL {p['qty']} x {p['symbol']} "
                              f"{p['strike']} {p['leg']} — order "
                              f"{resp.get('orderId','?')} — {reason} "
                              f"· est P&L ₹{p['pnl']:.0f}")
                except Exception as e:
                    self._log(f"⚠ LIVE EXIT FAILED: {e} — close manually "
                              "on Dhan app NOW")
                    return {"error": str(e)}
            else:
                self._log("⚠ cannot place live exit; close manually on Dhan")
        closed = dict(p)
        self.position = None
        return {"closed": closed}

    def _log(self, msg):
        entry = f"[{time.strftime('%H:%M:%S')}] {msg}"
        self.log.append(entry)
        print("  " + entry)
