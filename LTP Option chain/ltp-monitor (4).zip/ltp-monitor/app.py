"""
LTP Option-Chain Monitor + Autopilot -- run with:  python app.py
Then open  http://127.0.0.1:8000
Credentials are managed in the dashboard's Settings panel (gear icon).
"""

import os
import traceback

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import config
from nse_client import NSEClient, SensexClient
from analyzer import analyze, deep_ai_analysis, ai_signal
from broker_adapter import DhanClient, DhanOrders
from auto_trader import Autopilot

BASE = os.path.dirname(os.path.abspath(__file__))
app = FastAPI(title="LTP Option Chain Monitor")

nse = NSEClient()
bse = SensexClient()
_dhan = None
SYMBOLS = {"NIFTY", "BANKNIFTY", "FINNIFTY", "SENSEX"}


def dhan_client():
    """(Re)build the Dhan client lazily so Settings changes apply live."""
    global _dhan
    if not DhanClient.available():
        _dhan = None
        return None
    if _dhan is None:
        _dhan = DhanClient()
    return _dhan


def reset_dhan():
    global _dhan
    _dhan = None


def orders_factory():
    c = dhan_client()
    return DhanOrders(c) if c else None


def get_chain(symbol: str) -> dict:
    symbol = symbol.upper()
    if symbol not in SYMBOLS:
        raise HTTPException(400, f"Unknown symbol {symbol}")
    d = dhan_client()
    if d is not None:
        return d.option_chain(symbol)
    if symbol == "SENSEX":
        return bse.option_chain()
    return nse.option_chain(symbol)


pilot = Autopilot(get_chain, orders_factory)


# ------------------------------------------------------------ data & AI
@app.get("/api/analysis/{symbol}")
def api_analysis(symbol: str):
    try:
        return analyze(get_chain(symbol))
    except HTTPException:
        raise
    except Exception as e:
        traceback.print_exc()
        return JSONResponse(status_code=502, content={"error": str(e)})


@app.get("/api/signal/{symbol}")
def api_signal(symbol: str):
    try:
        analysis = analyze(get_chain(symbol))
        sig = ai_signal(analysis)
        pilot.last_signal = sig
        return {"signal": sig, "analysis_snapshot": {
            "spot": analysis["spot"], "bias": analysis["bias"],
            "risk_meter": analysis["risk_meter"]}}
    except Exception as e:
        traceback.print_exc()
        return JSONResponse(status_code=502, content={"error": str(e)})


@app.get("/api/ai/{symbol}")
def api_ai(symbol: str):
    try:
        return {"analysis": deep_ai_analysis(analyze(get_chain(symbol)))}
    except Exception as e:
        traceback.print_exc()
        return JSONResponse(status_code=502, content={"error": str(e)})


# ------------------------------------------------------------ settings
class SettingsIn(BaseModel):
    dhan_client_id: str | None = None
    dhan_access_token: str | None = None
    anthropic_api_key: str | None = None
    theme: str | None = None
    paper_mode: bool | None = None
    auto_execute: bool | None = None
    min_confidence: int | None = None
    max_trades_per_day: int | None = None
    lots_per_trade: int | None = None


@app.get("/api/settings")
def get_settings():
    return config.public_view(config.load())


@app.post("/api/settings")
def set_settings(s: SettingsIn):
    updates = {k: v for k, v in s.model_dump().items() if v is not None}
    # empty string means "don't change" for secrets
    for k in ("dhan_client_id", "dhan_access_token", "anthropic_api_key"):
        if updates.get(k) == "":
            updates.pop(k)
    cfg = config.save(updates)
    if any(k.startswith("dhan") for k in updates):
        reset_dhan()
    return config.public_view(cfg)


# ------------------------------------------------------------ trading
class ExecuteIn(BaseModel):
    symbol: str


@app.post("/api/execute")
def api_execute(body: ExecuteIn):
    """Manual confirm: enter the last generated signal."""
    try:
        analysis = analyze(get_chain(body.symbol))
        sig = pilot.last_signal or ai_signal(analysis)
        if sig["signal"] == "WAIT":
            return {"error": "Current signal is WAIT — nothing to execute."}
        if pilot.position:
            return {"error": "A position is already open — exit it first."}
        pilot.symbol = body.symbol.upper()
        pilot.execute(sig, analysis, manual=True)
        return pilot.status()
    except Exception as e:
        traceback.print_exc()
        return JSONResponse(status_code=502, content={"error": str(e)})


@app.post("/api/exit")
def api_exit():
    res = pilot.exit_position("manual exit from dashboard")
    return {**res, **pilot.status()}


class PilotIn(BaseModel):
    symbol: str


@app.post("/api/autopilot/start")
def pilot_start(body: PilotIn):
    return pilot.start(body.symbol)


@app.post("/api/autopilot/stop")
def pilot_stop():
    return pilot.stop()


@app.get("/api/autopilot/status")
def pilot_status():
    return pilot.status()


@app.get("/")
def index():
    return FileResponse(os.path.join(BASE, "static", "dashboard.html"))


app.mount("/static", StaticFiles(directory=os.path.join(BASE, "static")), name="static")


if __name__ == "__main__":
    import uvicorn
    cfg = config.load()
    print("\n  LTP Option Chain Monitor  ->  http://127.0.0.1:8000")
    if DhanClient.available():
        print("  ✓ Dhan credentials found — live feed enabled")
    else:
        print("  ! Add Dhan credentials in the dashboard Settings (gear icon)")
    print(f"  mode: {'PAPER (simulated orders)' if cfg['paper_mode'] else '⚠ LIVE ORDERS'}\n")
    uvicorn.run(app, host="127.0.0.1", port=8000)
