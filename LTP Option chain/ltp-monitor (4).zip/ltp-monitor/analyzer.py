"""
LTP-Calculator style option-chain analytics.

Implements the concepts popularized by volume/OI based option-chain reading:
  * Buyer vs Seller dominance per strike (volume vs OI-change behaviour)
  * Support / resistance from PE / CE open-interest concentration
  * Max Pain, PCR (OI & volume), IV skew
  * Per-strike "risk level" for option sellers (safe -> danger zones)
  * A market-state machine (trending / rangebound / reversal-watch)
  * Rule-based trade suggestions with entry / SL / target zones

NOTHING here is financial advice -- it is a decision-support dashboard.
"""

import json
import os
import urllib.request


# ---------------------------------------------------------------- core maths

def max_pain(rows):
    """Strike where total option writers' loss is minimum."""
    strikes = [r["strike"] for r in rows]
    best, best_val = None, float("inf")
    for k in strikes:
        pain = 0.0
        for r in rows:
            s = r["strike"]
            pain += r["ce"]["oi"] * max(0.0, k - s)   # CE writers lose above strike
            pain += r["pe"]["oi"] * max(0.0, s - k)   # PE writers lose below strike
        if pain < best_val:
            best, best_val = k, pain
    return best


def classify_leg(leg):
    """
    Volume vs OI interpretation (LTP-calculator style):
      price up  + OI up   -> long build-up      (buyers in control)
      price down+ OI up   -> short build-up     (sellers/writers in control)
      price up  + OI down -> short covering
      price down+ OI down -> long unwinding
    High volume with small net OI change = intraday churn (weak hands).
    """
    price_up = leg["chg"] > 0
    oi_up = leg["oi_chg"] > 0
    if price_up and oi_up:
        state = "long-buildup"
    elif (not price_up) and oi_up:
        state = "short-buildup"
    elif price_up and not oi_up:
        state = "short-covering"
    else:
        state = "long-unwinding"
    churn = leg["volume"] > 0 and abs(leg["oi_chg"]) < 0.15 * leg["volume"]
    return state, churn


def analyze(chain: dict) -> dict:
    rows = chain["rows"]
    spot = chain["spot"] or 0
    if not rows or not spot:
        return {"error": "empty chain"}

    # focus window: ~10 strikes either side of ATM
    atm = min(rows, key=lambda r: abs(r["strike"] - spot))["strike"]
    idx = [i for i, r in enumerate(rows) if r["strike"] == atm][0]
    lo, hi = max(0, idx - 10), min(len(rows), idx + 11)
    win = rows[lo:hi]

    tot_ce_oi = sum(r["ce"]["oi"] for r in rows) or 1
    tot_pe_oi = sum(r["pe"]["oi"] for r in rows) or 1
    tot_ce_vol = sum(r["ce"]["volume"] for r in rows) or 1
    tot_pe_vol = sum(r["pe"]["volume"] for r in rows) or 1

    pcr_oi = tot_pe_oi / tot_ce_oi
    pcr_vol = tot_pe_vol / tot_ce_vol
    mp = max_pain(win)

    # supports & resistances from OI concentration
    res = sorted(win, key=lambda r: r["ce"]["oi"], reverse=True)[:3]
    sup = sorted(win, key=lambda r: r["pe"]["oi"], reverse=True)[:3]
    resistance = [r["strike"] for r in res]
    support = [r["strike"] for r in sup]

    # per-strike risk levels + dominance
    strikes_out = []
    for r in win:
        ce_state, ce_churn = classify_leg(r["ce"])
        pe_state, pe_churn = classify_leg(r["pe"])
        ce_score = _seller_risk(r["ce"], r["strike"], spot, side="CE")
        pe_score = _seller_risk(r["pe"], r["strike"], spot, side="PE")
        strikes_out.append({
            "strike": r["strike"],
            "ce": {**r["ce"], "state": ce_state, "churn": ce_churn,
                   "risk": ce_score, "risk_label": _risk_label(ce_score)},
            "pe": {**r["pe"], "state": pe_state, "churn": pe_churn,
                   "risk": pe_score, "risk_label": _risk_label(pe_score)},
        })

    # market state machine
    bias, state, confidence = _market_state(
        spot, mp, pcr_oi, pcr_vol, support, resistance, win
    )

    # overall risk meter 0-100 (how hostile conditions are for fresh positions)
    dist_mp = abs(spot - mp) / spot * 100
    ivs = [r["ce"]["iv"] for r in win if r["ce"]["iv"]] + \
          [r["pe"]["iv"] for r in win if r["pe"]["iv"]]
    avg_iv = sum(ivs) / len(ivs) if ivs else 0
    risk_meter = min(100, round(
        dist_mp * 12 +                       # stretched from max pain
        (abs(pcr_oi - 1.0) * 25) +           # one-sided positioning
        (avg_iv * 1.2)                       # elevated IV
    ))

    suggestions = _suggest(bias, state, spot, atm, support, resistance, mp,
                           strikes_out, pcr_oi)

    return {
        "symbol": chain["symbol"],
        "spot": spot,
        "expiry": chain["expiry"],
        "exchange_timestamp": chain.get("timestamp"),
        "source": chain.get("source"),
        "atm": atm,
        "max_pain": mp,
        "pcr_oi": round(pcr_oi, 2),
        "pcr_volume": round(pcr_vol, 2),
        "avg_iv": round(avg_iv, 1),
        "support": support,
        "resistance": resistance,
        "bias": bias,
        "market_state": state,
        "confidence": confidence,
        "risk_meter": risk_meter,
        "strikes": strikes_out,
        "suggestions": suggestions,
        "disclaimer": ("Educational decision-support only. Options carry high "
                       "risk; verify with your broker's live feed before "
                       "trading."),
    }


def _seller_risk(leg, strike, spot, side):
    """0 (safe for writer) -> 100 (danger zone). Mirrors the green/yellow/red
    zoning shown in LTP-calculator style tools."""
    dist = (strike - spot) / spot if side == "CE" else (spot - strike) / spot
    dist_score = max(0.0, 1.0 - max(dist, 0) * 40)        # near/ITM = risky
    vol_oi = leg["volume"] / leg["oi"] if leg["oi"] else 2.0
    churn_score = min(1.0, vol_oi / 3.0)                  # heavy churn = unstable
    unwind = 1.0 if leg["oi_chg"] < 0 and leg["chg"] > 0 else 0.0
    return round(min(100, (0.55 * dist_score + 0.30 * churn_score
                           + 0.15 * unwind) * 100))


def _risk_label(score):
    if score >= 70:
        return "danger"
    if score >= 40:
        return "caution"
    return "safe"


def _market_state(spot, mp, pcr_oi, pcr_vol, support, resistance, win):
    bull = bear = 0
    if pcr_oi > 1.15: bull += 2
    elif pcr_oi > 1.0: bull += 1
    if pcr_oi < 0.85: bear += 2
    elif pcr_oi < 1.0: bear += 1
    if spot > mp: bull += 1
    else: bear += 1
    if pcr_vol > 1.1: bull += 1
    if pcr_vol < 0.9: bear += 1

    # writer behaviour near ATM
    near = [r for r in win if abs(r["strike"] - spot) / spot < 0.01]
    for r in near:
        if classify_leg(r["pe"])[0] == "short-buildup": bull += 1   # PE writing
        if classify_leg(r["ce"])[0] == "short-buildup": bear += 1   # CE writing

    net = bull - bear
    if net >= 3: bias = "BULLISH"
    elif net <= -3: bias = "BEARISH"
    elif net >= 1: bias = "MILD BULLISH"
    elif net <= -1: bias = "MILD BEARISH"
    else: bias = "NEUTRAL"

    rng = (min(resistance) - max(support)) / spot if support and resistance else 0
    if support and resistance and max(support) < spot < min(resistance) and rng < 0.02:
        state = "RANGEBOUND (compression between OI walls)"
    elif abs(spot - mp) / spot > 0.012:
        state = "STRETCHED — reversal-watch toward max pain"
    else:
        state = "TRENDING with " + bias.lower() + " undertone"

    confidence = min(95, 40 + abs(net) * 10)
    return bias, state, confidence


def _suggest(bias, state, spot, atm, support, resistance, mp, strikes, pcr):
    out = []
    sup = max(support) if support else atm
    res = min(resistance) if resistance else atm

    def strike_row(k):
        for s in strikes:
            if s["strike"] == k:
                return s
        return None

    if bias in ("BULLISH", "MILD BULLISH"):
        row = strike_row(atm)
        ce_ltp = row["ce"]["ltp"] if row else 0
        out.append({
            "action": "BUY", "instrument": f"{atm} CE",
            "type": "directional",
            "entry_hint": f"near LTP ₹{ce_ltp:.1f} on a hold above support {sup}",
            "stoploss": f"spot close below {sup}",
            "target": f"resistance zone {res}",
            "rationale": f"{bias}: PCR {pcr}, PE writers defending {sup}, "
                         f"spot above max pain {mp}.",
        })
        out.append({
            "action": "SELL", "instrument": f"{sup} PE",
            "type": "premium-selling",
            "entry_hint": "only with defined risk (spread or hedge)",
            "stoploss": f"spot breaks {sup} decisively",
            "target": "premium decay to ~40-50%",
            "rationale": f"Highest PE OI wall at {sup} acting as support.",
        })
    elif bias in ("BEARISH", "MILD BEARISH"):
        row = strike_row(atm)
        pe_ltp = row["pe"]["ltp"] if row else 0
        out.append({
            "action": "BUY", "instrument": f"{atm} PE",
            "type": "directional",
            "entry_hint": f"near LTP ₹{pe_ltp:.1f} on rejection from {res}",
            "stoploss": f"spot close above {res}",
            "target": f"support zone {sup}",
            "rationale": f"{bias}: PCR {pcr}, CE writers capping {res}, "
                         f"spot vs max pain {mp}.",
        })
        out.append({
            "action": "SELL", "instrument": f"{res} CE",
            "type": "premium-selling",
            "entry_hint": "only with defined risk (spread or hedge)",
            "stoploss": f"spot breaks {res} decisively",
            "target": "premium decay to ~40-50%",
            "rationale": f"Highest CE OI wall at {res} acting as resistance.",
        })
    else:
        out.append({
            "action": "SELL", "instrument": f"{res} CE + {sup} PE (short strangle)",
            "type": "rangebound",
            "entry_hint": "both legs, hedged with far OTM wings (iron condor)",
            "stoploss": f"spot exits {sup}–{res} range",
            "target": "theta decay while range holds",
            "rationale": f"Neutral state: {state}. OI walls at {sup}/{res}, "
                         f"max pain {mp} near spot.",
        })
    return out


# ---------------------------------------------------------------- Claude AI

def ai_signal(analysis: dict, api_key: str | None = None) -> dict:
    """Structured trade decision from Claude: exact entry/SL/target price
    points as JSON, rendered as a signal card in the UI and consumed by
    the autopilot. Falls back to the rule engine when no key is set."""
    import config as _cfg
    api_key = api_key or _cfg.load().get("anthropic_api_key") \
        or os.environ.get("ANTHROPIC_API_KEY")

    fallback = _rule_signal(analysis)
    if not api_key:
        fallback["source"] = "rule-engine (add Anthropic key in Settings for AI)"
        return fallback

    compact = {k: analysis[k] for k in (
        "symbol", "spot", "expiry", "atm", "max_pain", "pcr_oi", "pcr_volume",
        "avg_iv", "support", "resistance", "bias", "market_state",
        "risk_meter")}
    compact["strikes"] = [
        {"strike": s["strike"],
         "ce": {k: s["ce"].get(k) for k in ("ltp", "oi", "oi_chg", "volume", "state", "risk_label")},
         "pe": {k: s["pe"].get(k) for k in ("ltp", "oi", "oi_chg", "volume", "state", "risk_label")}}
        for s in analysis["strikes"]
    ]

    prompt = (
        "You are an options-flow analyst for Indian index options. Based on "
        "this volume/OI option-chain summary, output a single trade decision "
        "as JSON ONLY (no markdown, no preamble). Schema:\n"
        '{"signal":"BUY_CE|BUY_PE|WAIT","strike":<number>,'
        '"entry":<option premium to enter at>,"stoploss":<premium SL>,'
        '"target1":<premium>,"target2":<premium>,'
        '"spot_invalidation":<spot level that kills the idea>,'
        '"confidence":<0-100>,"timeframe":"intraday",'
        '"reasons":[<3-5 short strings>],"risk_note":<string>}\n'
        "Rules: choose WAIT if volumes are zero/stale, if market is closed, "
        "if risk_meter>70, or if there is no clear edge — WAIT is a good "
        "answer. Entry/SL/targets must be realistic option premiums derived "
        "from the given LTPs. Prefer ATM or first OTM strikes.\n\n"
        + json.dumps(compact)
    )

    body = json.dumps({
        "model": "claude-sonnet-4-6",
        "max_tokens": 600,
        "messages": [{"role": "user", "content": prompt}],
    }).encode()

    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages", data=body,
        headers={"Content-Type": "application/json", "x-api-key": api_key,
                 "anthropic-version": "2023-06-01"})
    try:
        with urllib.request.urlopen(req, timeout=45) as resp:
            data = json.loads(resp.read())
        text = "".join(b.get("text", "") for b in data.get("content", []))
        text = text.replace("```json", "").replace("```", "").strip()
        sig = json.loads(text)
        sig["source"] = "Claude AI"
        # attach the option security_id so the executor can trade it
        _attach_security_id(sig, analysis)
        return sig
    except Exception as e:
        fallback["source"] = f"rule-engine (AI error: {e})"
        return fallback


def _rule_signal(analysis: dict) -> dict:
    """Deterministic signal derived from the rule engine."""
    bias = analysis["bias"]
    atm = analysis["atm"]
    row = next((s for s in analysis["strikes"] if s["strike"] == atm), None)
    stale = not any(s["ce"]["volume"] or s["pe"]["volume"]
                    for s in analysis["strikes"])
    if stale or analysis["risk_meter"] > 70 or bias == "NEUTRAL" or not row:
        sig = {"signal": "WAIT", "strike": atm, "entry": 0, "stoploss": 0,
               "target1": 0, "target2": 0,
               "spot_invalidation": analysis["max_pain"],
               "confidence": 40, "timeframe": "intraday",
               "reasons": ["No clear edge or stale/zero volume data",
                           f"Risk meter {analysis['risk_meter']}/100",
                           f"Bias: {bias}"],
               "risk_note": "Stand aside until live flow confirms."}
        return sig
    leg = "ce" if "BULL" in bias else "pe"
    ltp = row[leg]["ltp"]
    spot = analysis["spot"]
    sup = max([s for s in analysis["support"] if s < spot] or [spot * 0.996])
    res = min([s for s in analysis["resistance"] if s > spot] or [spot * 1.004])
    sig = {
        "signal": "BUY_CE" if leg == "ce" else "BUY_PE",
        "strike": atm,
        "entry": round(ltp, 1),
        "stoploss": round(ltp * 0.70, 1),
        "target1": round(ltp * 1.30, 1),
        "target2": round(ltp * 1.60, 1),
        "spot_invalidation": sup if leg == "ce" else res,
        "confidence": analysis["confidence"],
        "timeframe": "intraday",
        "reasons": [f"Bias {bias}, PCR {analysis['pcr_oi']}",
                    f"OI walls: support {sup} / resistance {res}",
                    f"Spot vs max pain: {analysis['spot']:.0f} vs {analysis['max_pain']}"],
        "risk_note": "Rule-based estimate; premiums use fixed 30% SL / "
                     "30-60% targets.",
    }
    _attach_security_id(sig, analysis)
    return sig


def _attach_security_id(sig: dict, analysis: dict):
    if sig.get("signal") not in ("BUY_CE", "BUY_PE"):
        return
    leg = "ce" if sig["signal"] == "BUY_CE" else "pe"
    row = next((s for s in analysis["strikes"]
                if s["strike"] == sig.get("strike")), None)
    if row:
        sig["security_id"] = row[leg].get("security_id")
        sig["option_ltp"] = row[leg]["ltp"]


def deep_ai_analysis(analysis: dict, api_key: str | None = None) -> str:
    """Optional: send the computed summary to Claude for narrative deep-dive.
    Requires ANTHROPIC_API_KEY in environment. Falls back gracefully."""
    api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        import config as _cfg
        api_key = _cfg.load().get("anthropic_api_key")
    if not api_key:
        return ("(Add your Anthropic API key in Settings to enable Claude "
                "deep analysis. Showing rule-engine output only.)")

    compact = {k: analysis[k] for k in (
        "symbol", "spot", "expiry", "atm", "max_pain", "pcr_oi", "pcr_volume",
        "avg_iv", "support", "resistance", "bias", "market_state",
        "risk_meter", "suggestions")}
    compact["top_strikes"] = [
        {"strike": s["strike"],
         "ce": {k: s["ce"][k] for k in ("ltp", "oi", "oi_chg", "volume", "state", "risk_label")},
         "pe": {k: s["pe"][k] for k in ("ltp", "oi", "oi_chg", "volume", "state", "risk_label")}}
        for s in analysis["strikes"][::2]
    ]

    body = json.dumps({
        "model": "claude-sonnet-4-6",
        "max_tokens": 900,
        "messages": [{
            "role": "user",
            "content": (
                "You are an options-flow analyst. Given this Indian index "
                "option-chain summary (volume/OI based), write a concise "
                "deep-dive: 1) what writers are doing, 2) key risk zones, "
                "3) scenarios (bull/bear/range) with invalidation levels, "
                "4) critique of the rule-engine suggestions. Be specific, "
                "no fluff, end with a one-line risk warning.\n\n"
                + json.dumps(compact)
            ),
        }],
    }).encode()

    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=body,
        headers={
            "Content-Type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=45) as resp:
            data = json.loads(resp.read())
        return "".join(b.get("text", "") for b in data.get("content", []))
    except Exception as e:
        return f"(Claude deep analysis unavailable: {e})"
