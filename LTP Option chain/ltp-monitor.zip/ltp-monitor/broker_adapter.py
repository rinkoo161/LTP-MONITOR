"""
OPTIONAL: true tick-level real-time via a broker API.

NSE/BSE public endpoints give ~1-3 minute snapshots and rate-limit polling.
For live LTP ticks (like paid LTP-calculator tools use), connect a broker
market-data API. Two popular free/cheap options in India:

1) DhanHQ  (free market feed with a Dhan account)
   pip install dhanhq
   Docs: https://dhanhq.co/docs/

2) Zerodha Kite Connect (paid, ~Rs 2000/month)
   pip install kiteconnect

Implement `option_chain(symbol)` below returning the same dict shape as
nse_client.NSEClient.option_chain(), then in app.py swap:

    nse = NSEClient()      ->      nse = BrokerClient()

Dict shape required:
{
  "symbol": "NIFTY", "spot": 24500.5, "expiry": "17-Jul-2026",
  "timestamp": "...", "source": "Dhan live",
  "rows": [ { "strike": 24500,
              "ce": {"ltp","oi","oi_chg","volume","iv","chg","bid","ask"},
              "pe": {...} }, ... ]
}
"""


class BrokerClient:
    def __init__(self, credentials: dict | None = None):
        self.credentials = credentials or {}
        raise NotImplementedError(
            "Fill in your broker's API calls here (see docstring)."
        )

    def option_chain(self, symbol: str) -> dict:
        raise NotImplementedError
