"""
Multi-agent trading system.

Agents (each runs on its own thread & cadence, communicating through a
shared Bus with a blackboard state store and pub/sub topics):

  market_data    every 3s      chain snapshots (Dhan rate limit = 1 req/3s;
                               upgrade path: Dhan WebSocket for true ticks)
  technical      every 60s     analyzer (OI walls, PCR, risk zones, bias)
  news           every 10min   RSS headlines -> Claude sentiment/risk flags
  social         every 10min   public feeds (Reddit RSS) -> retail mood
  fundamental    daily 8:45    macro/context brief for the day
  strategy       on analysis   builds trade signal (AI + full context)
  risk           on signal     pre-order gate: approves or rejects
  execution      on approval   places orders (paper/live), monitors, exits
  learning       EOD 15:35     reviews the day's trades, writes journal

Message flow:
  strategy -> topic 'signal'   -> risk
  risk     -> topic 'approved' -> execution
  execution-> topic 'closed'   -> learning (journal)

All timings are IST-aware; strategy/risk/execution stand down outside
market hours (09:15-15:30 Mon-Fri).
"""

import json
import os
import re
import threading
import time
import urllib.request
from collections import deque
from datetime import datetime, timedelta, timezone

import config
from analyzer import analyze, ai_signal

IST = timezone(timedelta(hours=5, minutes=30))
BASE = os.path.dirname(os.path.abspath(__file__))
JOURNAL = os.path.join(BASE, "journal.json")


def now_ist():
    return datetime.now(IST)


def market_open():
    t = now_ist()
    if t.weekday() >= 5:
        return False
    hm = t.hour * 60 + t.minute
    return 9 * 60 + 15 <= hm <= 15 * 60 + 30


def claude(prompt, api_key, max_tokens=500):
    body = json.dumps({"model": "claude-sonnet-4-6", "max_tokens": max_tokens,
                       "messages": [{"role": "user", "content": prompt}]}).encode()
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages", data=body,
        headers={"Content-Type": "application/json", "x-api-key": api_key,
                 "anthropic-version": "2023-06-01"})
    with urllib.request.urlopen(req, timeout=45) as r:
        data = json.loads(r.read())
    return "".join(b.get("text", "") for b in data.get("content", []))


# ================================================================== bus

class Bus:
    """Blackboard + pub/sub. Agents write state and publish events."""

    def __init__(self):
        self.state = {}                      # shared blackboard
        self._subs = {}                      # topic -> [callback]
        self._lock = threading.Lock()
        self.feed = deque(maxlen=400)        # global activity feed

    def set(self, key, value):
        with self._lock:
            self.state[key] = value

    def get(self, key, default=None):
        with self._lock:
            return self.state.get(key, default)

    def subscribe(self, topic, cb):
        self._subs.setdefault(topic, []).append(cb)

    def publish(self, topic, msg):
        for cb in self._subs.get(topic, []):
            try:
                cb(msg)
            except Exception as e:
                self.log("bus", f"⚠ handler error on {topic}: {e}")

    def log(self, agent, msg):
        line = f"[{now_ist().strftime('%H:%M:%S')}] [{agent}] {msg}"
        self.feed.append(line)
        print("  " + line)


# ================================================================== base

class Agent(threading.Thread):
    name = "agent"
    interval = 60

    def __init__(self, bus: Bus, ctx: dict):
        super().__init__(daemon=True)
        self.bus, self.ctx = bus, ctx
        self.stop_evt = threading.Event()
        self.last_run = None
        self.status = "idle"
        self.summary = ""

    def run(self):
        while not self.stop_evt.is_set():
            try:
                self.status = "running"
                self.cycle()
                self.status = "ok"
            except Exception as e:
                self.status = f"error: {e}"
                self.bus.log(self.name, f"⚠ {e}")
            self.last_run = now_ist().strftime("%H:%M:%S")
            self.stop_evt.wait(self.interval)
        self.status = "stopped"

    def cycle(self):
        raise NotImplementedError

    def info(self):
        return {"name": self.name, "interval": self.interval,
                "last_run": self.last_run, "status": self.status,
                "summary": self.summary}


# ================================================================== agents

class MarketDataAgent(Agent):
    name = "market_data"
    interval = 3           # Dhan option-chain hard limit: 1 request / 3 s

    def cycle(self):
        sym = self.bus.get("active_symbol", "NIFTY")
        chain = self.ctx["get_chain"](sym)
        self.bus.set(f"chain:{sym}", chain)
        self.bus.set("chain_ts", time.time())
        self.summary = f"{sym} spot {chain.get('spot')}"


class TechnicalAgent(Agent):
    name = "technical"
    interval = 60

    def cycle(self):
        sym = self.bus.get("active_symbol", "NIFTY")
        chain = self.bus.get(f"chain:{sym}")
        if not chain:
            self.summary = "waiting for market data"
            return
        analysis = analyze(chain)
        self.bus.set(f"analysis:{sym}", analysis)
        self.summary = (f"{analysis['bias']} · PCR {analysis['pcr_oi']} "
                        f"· risk {analysis['risk_meter']}")
        self.bus.publish("analysis", {"symbol": sym})


class NewsAgent(Agent):
    name = "news"
    interval = 600

    FEEDS = [
        "https://news.google.com/rss/search?q=nifty+OR+sensex+OR+%22indian+stock+market%22&hl=en-IN&gl=IN&ceid=IN:en",
    ]

    def cycle(self):
        heads = []
        for url in self.FEEDS:
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                xml = urllib.request.urlopen(req, timeout=15).read().decode("utf-8", "ignore")
                heads += re.findall(r"<title>(.*?)</title>", xml)[1:16]
            except Exception:
                continue
        heads = [re.sub(r"&\w+;", " ", h)[:140] for h in heads][:15]
        if not heads:
            self.summary = "no headlines fetched"
            return
        key = config.load().get("anthropic_api_key")
        if key:
            try:
                out = claude(
                    "Market news headlines for Indian indices below. Reply "
                    "ONLY JSON: {\"sentiment\":\"bullish|bearish|neutral\","
                    "\"risk_event\":true|false,\"note\":\"<one line>\"}\n\n"
                    + "\n".join(heads), key, 200)
                j = json.loads(out.replace("```json", "").replace("```", "").strip())
            except Exception:
                j = {"sentiment": "neutral", "risk_event": False,
                     "note": "AI sentiment unavailable"}
        else:
            j = {"sentiment": "neutral", "risk_event": False,
                 "note": "headlines collected (no AI key)"}
        j["headlines"] = heads[:8]
        self.bus.set("news", j)
        self.summary = f"{j['sentiment']} · risk_event={j['risk_event']}"


class SocialAgent(Agent):
    name = "social"
    interval = 600

    FEEDS = ["https://www.reddit.com/r/IndianStreetBets/.rss",
             "https://www.reddit.com/r/IndianStockMarket/.rss"]

    def cycle(self):
        titles = []
        for url in self.FEEDS:
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "ltp-monitor/1.0"})
                xml = urllib.request.urlopen(req, timeout=15).read().decode("utf-8", "ignore")
                titles += re.findall(r"<title>(.*?)</title>", xml)[1:9]
            except Exception:
                continue
        titles = [t[:120] for t in titles][:12]
        if not titles:
            self.summary = "no social data (feeds unavailable)"
            self.bus.set("social", {"mood": "unknown", "posts": []})
            return
        key = config.load().get("anthropic_api_key")
        mood = "unknown"
        if key:
            try:
                out = claude("Retail trader forum post titles (India). One "
                             "word only - overall mood: euphoric, bullish, "
                             "neutral, bearish, or fearful.\n\n" + "\n".join(titles),
                             key, 20)
                mood = out.strip().lower().split()[0]
            except Exception:
                pass
        self.bus.set("social", {"mood": mood, "posts": titles[:6]})
        self.summary = f"retail mood: {mood}"


class FundamentalAgent(Agent):
    name = "fundamental"
    interval = 3600        # checks hourly, produces once per day at ~08:45

    def cycle(self):
        today = now_ist().strftime("%Y-%m-%d")
        cur = self.bus.get("macro") or {}
        if cur.get("date") == today:
            self.summary = f"today's brief ready ({cur.get('stance','')})"
            return
        if now_ist().hour < 8:
            self.summary = "waiting for 08:45 IST"
            return
        news = self.bus.get("news") or {}
        key = config.load().get("anthropic_api_key")
        brief = {"date": today, "stance": "neutral",
                 "note": "no AI key — neutral macro assumption"}
        if key:
            try:
                out = claude(
                    "Write a 3-line pre-market macro brief for Indian index "
                    "option traders for today. End with STANCE: bullish/"
                    "bearish/neutral. Recent headlines:\n"
                    + "\n".join(news.get("headlines", ["none"])), key, 300)
                stance = "neutral"
                m = re.search(r"STANCE:\s*(\w+)", out, re.I)
                if m:
                    stance = m.group(1).lower()
                brief = {"date": today, "stance": stance, "note": out.strip()}
            except Exception as e:
                brief["note"] = f"AI unavailable: {e}"
        self.bus.set("macro", brief)
        self.summary = f"daily brief: {brief['stance']}"


class StrategyAgent(Agent):
    name = "strategy"
    interval = 5           # event-driven; the loop only drains a queue

    def __init__(self, bus, ctx):
        super().__init__(bus, ctx)
        self._pending = deque()
        bus.subscribe("analysis", self._pending.append)
        self._last_signal_ts = 0

    def cycle(self):
        if not self._pending:
            return
        msg = self._pending.pop()
        self._pending.clear()
        if not market_open():
            self.summary = "market closed — standing down"
            return
        if self.bus.get("position"):
            self.summary = "position open — no new signals"
            return
        if time.time() - self._last_signal_ts < 120:
            return                       # cooldown between signals
        sym = msg["symbol"]
        analysis = self.bus.get(f"analysis:{sym}")
        if not analysis or analysis.get("error"):
            return
        context = {
            "news": self.bus.get("news"),
            "social_mood": (self.bus.get("social") or {}).get("mood"),
            "macro": (self.bus.get("macro") or {}).get("stance"),
        }
        sig = ai_signal(analysis, context=context)
        self.bus.set("last_signal", sig)
        self._last_signal_ts = time.time()
        self.summary = f"{sig['signal']} {sig.get('strike','')} conf {sig['confidence']}%"
        self.bus.log(self.name, self.summary)
        if sig["signal"] != "WAIT":
            self.bus.publish("signal", {"symbol": sym, "signal": sig,
                                        "analysis": analysis})


class RiskAgent(Agent):
    name = "risk"
    interval = 5

    def __init__(self, bus, ctx):
        super().__init__(bus, ctx)
        self._queue = deque()
        bus.subscribe("signal", self._queue.append)
        self.daily_pnl = 0.0
        bus.subscribe("closed", self._on_closed)

    def _on_closed(self, msg):
        self.daily_pnl += msg.get("pnl", 0)

    def evaluate(self, job):
        """Run all pre-order checks. Returns (ok, checks)."""
        sig, cfg = job["signal"], config.load()
        checks = []
        ok = True

        def check(cond, label):
            nonlocal ok
            checks.append(("✓" if cond else "✗") + " " + label)
            ok = ok and cond

        trades = self.bus.get("trades_today", 0)
        check(market_open(), "market open")
        check(self.bus.get("position") is None, "no open position")
        check(trades < cfg["max_trades_per_day"],
              f"trades {trades}/{cfg['max_trades_per_day']}")
        check(sig["confidence"] >= cfg["min_confidence"],
              f"confidence {sig['confidence']}≥{cfg['min_confidence']}")
        check(sig.get("entry", 0) > 0 and sig.get("stoploss", 0) > 0,
              "valid price points")
        news = self.bus.get("news") or {}
        check(not news.get("risk_event"), "no active news risk event")
        max_loss = (sig.get("entry", 0) - sig.get("stoploss", 0)) \
            * cfg["lot_sizes"].get(job["symbol"], 75) * cfg["lots_per_trade"]
        check(self.daily_pnl - max_loss > -abs(cfg.get("daily_loss_limit", 5000)),
              f"daily loss limit (risking ₹{max_loss:.0f}, day P&L ₹{self.daily_pnl:.0f})")
        data_age = time.time() - (self.bus.get("chain_ts") or 0)
        check(data_age < 30, f"fresh data ({data_age:.0f}s old)")
        return ok, checks

    def cycle(self):
        if not self._queue:
            return
        job = self._queue.popleft()
        ok, checks = self.evaluate(job)
        sig = job["signal"]
        verdict = "APPROVED" if ok else "REJECTED"
        self.summary = f"{verdict}: {sig['signal']} {sig.get('strike','')}"
        self.bus.log(self.name, f"{verdict} — " + " · ".join(checks))
        self.bus.set("last_risk_check", {"verdict": verdict, "checks": checks})
        if ok:
            self.bus.publish("approved", job)


class ExecutionAgent(Agent):
    name = "execution"
    interval = 5           # also monitors open position every cycle

    def __init__(self, bus, ctx):
        super().__init__(bus, ctx)
        self._queue = deque()
        bus.subscribe("approved", self._queue.append)

    def cycle(self):
        if self._queue:
            self._enter(self._queue.popleft())
        self._monitor()

    def _enter(self, job):
        cfg = config.load()
        if not cfg["auto_execute"]:
            self.bus.set("pending_confirmation", job)
            self.summary = "signal approved — awaiting your confirmation"
            self.bus.log(self.name, "auto-execute OFF: order waits for "
                                    "manual confirm in dashboard")
            return
        self.place(job)

    def place(self, job, manual=False):
        cfg = config.load()
        sig, analysis, sym = job["signal"], job["analysis"], job["symbol"]
        lot = cfg["lot_sizes"].get(sym, 75)
        qty = lot * cfg["lots_per_trade"]
        leg = "CE" if sig["signal"] == "BUY_CE" else "PE"
        label = f"{sym} {sig['strike']} {leg}"
        fill = sig.get("option_ltp") or sig["entry"]
        if cfg["paper_mode"]:
            order_id = f"PAPER-{int(time.time())}"
            self.bus.log(self.name, f"📄 PAPER BUY {qty} x {label} @ ₹{fill}")
        else:
            orders = self.ctx["orders_factory"]()
            if orders is None or not sig.get("security_id"):
                self.bus.log(self.name, "⚠ cannot place live order "
                                        "(no broker / security_id)")
                return
            resp = orders.place(sym, sig["security_id"], "BUY", qty, "MARKET")
            order_id = resp.get("orderId", "?")
            self.bus.log(self.name, f"🔴 LIVE BUY {qty} x {label} — "
                                    f"order {order_id}")
        self.bus.set("position", {
            "symbol": sym, "strike": sig["strike"], "leg": leg, "qty": qty,
            "entry": fill, "stoploss": sig["stoploss"],
            "target1": sig["target1"], "target2": sig["target2"],
            "spot_invalidation": sig.get("spot_invalidation"),
            "security_id": sig.get("security_id"), "order_id": order_id,
            "opened": now_ist().strftime("%H:%M:%S"), "ltp": fill,
            "pnl": 0.0, "t1_hit": False, "paper": cfg["paper_mode"],
            "manual": manual,
        })
        self.bus.set("trades_today", self.bus.get("trades_today", 0) + 1)
        self.bus.set("pending_confirmation", None)

    def _monitor(self):
        p = self.bus.get("position")
        if not p:
            self.summary = self.summary or "idle"
            return
        sym = p["symbol"]
        chain = self.bus.get(f"chain:{sym}")
        analysis = self.bus.get(f"analysis:{sym}")
        if not chain:
            return
        row = next((r for r in chain["rows"] if r["strike"] == p["strike"]), None)
        if not row:
            return
        ltp = row[p["leg"].lower()]["ltp"]
        p["ltp"] = ltp
        p["pnl"] = round((ltp - p["entry"]) * p["qty"], 0)
        spot = chain["spot"]
        self.summary = f"{p['strike']} {p['leg']} LTP ₹{ltp} P&L ₹{p['pnl']:.0f}"

        reason = None
        if ltp <= p["stoploss"]:
            reason = f"stoploss (₹{ltp} ≤ ₹{p['stoploss']})"
        elif ltp >= p["target2"]:
            reason = f"target-2 (₹{ltp})"
        elif p["t1_hit"] and ltp <= p["entry"]:
            reason = "gave back gains after T1"
        elif p.get("spot_invalidation") and spot:
            inv = p["spot_invalidation"]
            if (p["leg"] == "CE" and spot < inv) or (p["leg"] == "PE" and spot > inv):
                reason = f"spot invalidation ({spot:.0f} vs {inv})"
        elif not market_open():
            reason = "market closing — squaring off intraday position"

        if not p["t1_hit"] and ltp >= p["target1"]:
            p["t1_hit"] = True
            p["stoploss"] = max(p["stoploss"], p["entry"])
            self.bus.log(self.name, f"✅ T1 hit ₹{ltp} — SL trailed to "
                                    f"breakeven ₹{p['stoploss']}")
        self.bus.set("position", p)
        if reason:
            self.exit(reason)

    def exit(self, reason="manual exit"):
        p = self.bus.get("position")
        if not p:
            return {"error": "no open position"}
        if p["paper"]:
            self.bus.log(self.name, f"📄 PAPER SELL {p['qty']} x {p['symbol']} "
                         f"{p['strike']} {p['leg']} @ ₹{p['ltp']} — {reason} "
                         f"· P&L ₹{p['pnl']:.0f}")
        else:
            orders = self.ctx["orders_factory"]()
            if orders and p.get("security_id"):
                try:
                    resp = orders.place(p["symbol"], p["security_id"], "SELL",
                                        p["qty"], "MARKET")
                    self.bus.log(self.name, f"🔴 LIVE SELL — order "
                                 f"{resp.get('orderId','?')} — {reason} "
                                 f"· est P&L ₹{p['pnl']:.0f}")
                except Exception as e:
                    self.bus.log(self.name, f"⚠ LIVE EXIT FAILED: {e} — "
                                            "close manually on Dhan NOW")
                    return {"error": str(e)}
            else:
                self.bus.log(self.name, "⚠ no broker for live exit — close "
                                        "manually on Dhan")
        closed = dict(p, closed=now_ist().strftime("%H:%M:%S"), reason=reason)
        self.bus.set("position", None)
        trades = self.bus.get("closed_trades", [])
        trades.append(closed)
        self.bus.set("closed_trades", trades)
        self.bus.publish("closed", closed)
        return {"closed": closed}


class LearningAgent(Agent):
    name = "learning"
    interval = 300

    def cycle(self):
        t = now_ist()
        today = t.strftime("%Y-%m-%d")
        done = self.bus.get("journal_done")
        trades = self.bus.get("closed_trades", [])
        if done == today:
            self.summary = "today's journal written"
            return
        if t.hour * 60 + t.minute < 15 * 60 + 35:
            self.summary = f"tracking {len(trades)} closed trades; journal at 15:35"
            return
        pnl = sum(x["pnl"] for x in trades)
        wins = sum(1 for x in trades if x["pnl"] > 0)
        stats = {"date": today, "trades": len(trades), "wins": wins,
                 "pnl": pnl}
        key = config.load().get("anthropic_api_key")
        critique = ""
        if key and trades:
            try:
                critique = claude(
                    "You are a trading coach. Review today's option trades "
                    "(entry/exit/reason/P&L below). In 5 bullet lines: what "
                    "worked, what didn't, and one concrete adjustment for "
                    "tomorrow.\n\n" + json.dumps(trades, default=str), key, 400)
            except Exception as e:
                critique = f"(AI review unavailable: {e})"
        entry = {**stats, "critique": critique, "trades_detail": trades}
        journal = []
        if os.path.exists(JOURNAL):
            try:
                journal = json.load(open(JOURNAL))
            except Exception:
                pass
        journal.append(entry)
        json.dump(journal, open(JOURNAL, "w"), indent=2, default=str)
        self.bus.set("journal_done", today)
        self.bus.set("journal_latest", entry)
        self.summary = f"journal: {len(trades)} trades, P&L ₹{pnl:.0f}"
        self.bus.log(self.name, self.summary)


# ================================================================== orchestrator

AGENT_CLASSES = [MarketDataAgent, TechnicalAgent, NewsAgent, SocialAgent,
                 FundamentalAgent, StrategyAgent, RiskAgent, ExecutionAgent,
                 LearningAgent]


class Orchestrator:
    def __init__(self, get_chain, orders_factory):
        self.bus = Bus()
        self.ctx = {"get_chain": get_chain, "orders_factory": orders_factory}
        self.agents = []
        self.running = False

    def start(self, symbol="NIFTY"):
        if self.running:
            self.bus.set("active_symbol", symbol.upper())
            return self.status()
        self.bus.set("active_symbol", symbol.upper())
        self.bus.set("trades_today", self.bus.get("trades_today", 0))
        self.agents = [cls(self.bus, self.ctx) for cls in AGENT_CLASSES]
        for a in self.agents:
            a.start()
        self.running = True
        self.bus.log("orchestrator",
                     f"all {len(self.agents)} agents started on "
                     f"{symbol.upper()} "
                     f"({'PAPER' if config.load()['paper_mode'] else 'LIVE'})")
        return self.status()

    def stop(self):
        for a in self.agents:
            a.stop_evt.set()
        self.running = False
        self.bus.log("orchestrator", "agents stopped")
        return self.status()

    def confirm_pending(self):
        """Manual confirmation of a risk-approved order."""
        job = self.bus.get("pending_confirmation")
        if not job:
            return {"error": "no risk-approved order pending"}
        ex = next((a for a in self.agents if a.name == "execution"), None)
        if not ex:
            return {"error": "execution agent not running"}
        ex.place(job, manual=True)
        return self.status()

    def exit_position(self, reason="manual exit from dashboard"):
        ex = next((a for a in self.agents if a.name == "execution"), None)
        if ex:
            return {**(ex.exit(reason) or {}), **self.status()}
        # not running: nothing to exit
        return {"error": "agents not running", **self.status()}

    def manual_trade(self, symbol: str):
        """Manual 'Confirm & place': still goes through the risk agent."""
        if not self.running:
            return {"error": "Start the agents first — every order must "
                             "pass the risk agent."}
        # a risk-approved order may already be waiting
        if self.bus.get("pending_confirmation"):
            return self.confirm_pending()
        sym = symbol.upper()
        analysis = self.bus.get(f"analysis:{sym}")
        sig = self.bus.get("last_signal")
        if not (analysis and sig) or sig.get("signal") == "WAIT":
            return {"error": "No actionable signal — press Get signal first."}
        job = {"symbol": sym, "signal": sig, "analysis": analysis}
        risk = next((a for a in self.agents if a.name == "risk"), None)
        ex = next((a for a in self.agents if a.name == "execution"), None)
        ok, checks = risk.evaluate(job)
        self.bus.set("last_risk_check",
                     {"verdict": "APPROVED" if ok else "REJECTED",
                      "checks": checks})
        if not ok:
            self.bus.log("risk", "REJECTED manual order — " + " · ".join(checks))
            return {"error": "Risk agent rejected the order",
                    "checks": checks}
        ex.place(job, manual=True)
        return self.status()

    def status(self):
        cfg = config.load()
        return {
            "running": self.running,
            "symbol": self.bus.get("active_symbol"),
            "market_open": market_open(),
            "paper_mode": cfg["paper_mode"],
            "auto_execute": cfg["auto_execute"],
            "trades_today": self.bus.get("trades_today", 0),
            "max_trades_per_day": cfg["max_trades_per_day"],
            "agents": [a.info() for a in self.agents],
            "position": self.bus.get("position"),
            "last_signal": self.bus.get("last_signal"),
            "last_risk_check": self.bus.get("last_risk_check"),
            "pending_confirmation": bool(self.bus.get("pending_confirmation")),
            "news": self.bus.get("news"),
            "social": self.bus.get("social"),
            "macro": self.bus.get("macro"),
            "journal_latest": self.bus.get("journal_latest"),
            "log": list(self.bus.feed)[-50:],
        }
