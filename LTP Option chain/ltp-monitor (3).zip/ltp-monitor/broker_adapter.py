"""
DhanHQ v2 option-chain adapter -- true live data for all four indices,
including SENSEX (BSE) and FINNIFTY (monthly).

Setup:
  1. Log in at web.dhan.co -> My Profile -> DhanHQ Trading APIs
     -> generate an Access Token (validity up to 24h/30d depending on plan).
     Note: the market **Data APIs pack** (~Rs 499/month) must be active
     on your Dhan account for the option-chain endpoint to return data.
  2. Set environment variables before starting the app:
        export DHAN_CLIENT_ID="1000000001"
        export DHAN_ACCESS_TOKEN="eyJ..."
  3. python app.py   (the app auto-detects Dhan and prefers it over NSE)

API reference: https://dhanhq.co/docs/v2/option-chain/
Rate limit: 1 unique option-chain request per 3 seconds -- this adapter
serializes and caches requests to stay inside that.
"""

import os
import time
import threading
import requests

API = "https://api.dhan.co/v2"

# Dhan security IDs for index underlyings (segment IDX_I).
# If one ever changes, look it up in the instrument master:
# https://images.dhan.co/api-data/api-scrip-master.csv  (SEM_SMST_SECURITY_ID
# for the index row) or https://dhanhq.co/docs/v2/instruments/
UNDERLYINGS = {
    "NIFTY":      13,
    "BANKNIFTY":  25,
    "FINNIFTY":   27,
    "MIDCPNIFTY": 442,
    "SENSEX":     51,
}

CACHE_TTL = 12          # seconds; well inside the 1-per-3s limit per symbol
MIN_GAP = 3.2           # seconds between any two option-chain calls


class DhanClient:
    def __init__(self, client_id=None, access_token=None):
        self.client_id = client_id or os.environ.get("DHAN_CLIENT_ID")
        self.token = access_token or os.environ.get("DHAN_ACCESS_TOKEN")
        if not (self.client_id and self.token):
            raise RuntimeError(
                "Set DHAN_CLIENT_ID and DHAN_ACCESS_TOKEN environment "
                "variables (see broker_adapter.py docstring)."
            )
        self._h = {
            "Content-Type": "application/json",
            "access-token": self.token,
            "client-id": str(self.client_id),
        }
        self._expiry = {}        # symbol -> (ts, expiry string)
        self._cache = {}         # symbol -> (ts, chain dict)
        self._lock = threading.Lock()
        self._last_call = 0.0

    @staticmethod
    def available() -> bool:
        return bool(os.environ.get("DHAN_CLIENT_ID")
                    and os.environ.get("DHAN_ACCESS_TOKEN"))

    # ------------------------------------------------------------- internals
    def _post(self, path, body):
        # global pacing: Dhan allows 1 option-chain request / 3 s
        with self._lock:
            wait = MIN_GAP - (time.time() - self._last_call)
            if wait > 0:
                time.sleep(wait)
            self._last_call = time.time()
        r = requests.post(API + path, json=body, headers=self._h, timeout=15)
        if r.status_code == 401:
            raise RuntimeError("Dhan says 401 Unauthorized — your access "
                               "token has expired; generate a new one at "
                               "web.dhan.co and update DHAN_ACCESS_TOKEN.")
        if r.status_code == 429:
            raise RuntimeError("Dhan rate limit hit — slow down polling.")
        r.raise_for_status()
        j = r.json()
        if j.get("status") != "success":
            raise RuntimeError(f"Dhan error: {j}")
        return j["data"]

    def _nearest_expiry(self, symbol):
        cached = self._expiry.get(symbol)
        if cached and time.time() - cached[0] < 1800:
            return cached[1]
        data = self._post("/optionchain/expirylist", {
            "UnderlyingScrip": UNDERLYINGS[symbol],
            "UnderlyingSeg": "IDX_I",
        })
        if not data:
            raise RuntimeError(f"No active expiries for {symbol}")
        exp = sorted(data)[0]
        self._expiry[symbol] = (time.time(), exp)
        return exp

    # ------------------------------------------------------------- public
    def option_chain(self, symbol: str) -> dict:
        symbol = symbol.upper()
        if symbol not in UNDERLYINGS:
            raise RuntimeError(f"Unknown symbol {symbol}")

        cached = self._cache.get(symbol)
        if cached and time.time() - cached[0] < CACHE_TTL:
            return cached[1]

        expiry = self._nearest_expiry(symbol)
        data = self._post("/optionchain", {
            "UnderlyingScrip": UNDERLYINGS[symbol],
            "UnderlyingSeg": "IDX_I",
            "Expiry": expiry,
        })

        spot = data.get("last_price")
        rows = []
        for strike_str, legs in (data.get("oc") or {}).items():
            strike = float(strike_str)
            rows.append({
                "strike": strike,
                "ce": _leg(legs.get("ce") or {}),
                "pe": _leg(legs.get("pe") or {}),
            })
        rows.sort(key=lambda r: r["strike"])

        chain = {
            "symbol": symbol,
            "spot": spot,
            "expiry": expiry,
            "timestamp": time.strftime("%d-%b-%Y %H:%M:%S"),
            "rows": rows,
            "totals": {},
            "source": "Dhan live",
        }
        self._cache[symbol] = (time.time(), chain)
        return chain


def _leg(d: dict) -> dict:
    oi = int(d.get("oi") or 0)
    prev_oi = int(d.get("previous_oi") or 0)
    ltp = float(d.get("last_price") or 0)
    prev_close = float(d.get("previous_close_price") or 0)
    return {
        "ltp": ltp,
        "oi": oi,
        "oi_chg": oi - prev_oi,
        "volume": int(d.get("volume") or 0),
        "iv": round(float(d.get("implied_volatility") or 0), 2),
        "chg": round(ltp - prev_close, 2) if prev_close else 0,
        "bid": float(d.get("top_bid_price") or 0),
        "ask": float(d.get("top_ask_price") or 0),
        # extra fields (Dhan provides greeks; analyzer ignores unknown keys)
        "delta": (d.get("greeks") or {}).get("delta"),
        "theta": (d.get("greeks") or {}).get("theta"),
    }
