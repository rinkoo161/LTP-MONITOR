"""
LTP Option-Chain Monitor -- run with:  python app.py
Then open  http://127.0.0.1:8000
"""

import os
import traceback

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from nse_client import NSEClient, SensexClient
from analyzer import analyze, deep_ai_analysis
from broker_adapter import DhanClient

BASE = os.path.dirname(os.path.abspath(__file__))

app = FastAPI(title="LTP Option Chain Monitor")
nse = NSEClient()
bse = SensexClient()
dhan = None
if DhanClient.available():
    dhan = DhanClient()
    print("  ✓ Dhan credentials found — using LIVE broker feed for all symbols")
else:
    print("  ! No Dhan credentials — falling back to public NSE/BSE snapshots")
    print("    (set DHAN_CLIENT_ID and DHAN_ACCESS_TOKEN for live data)")

SYMBOLS = {"NIFTY", "BANKNIFTY", "FINNIFTY", "SENSEX"}


def get_chain(symbol: str) -> dict:
    symbol = symbol.upper()
    if symbol not in SYMBOLS:
        raise HTTPException(400, f"Unknown symbol {symbol}")
    if dhan is not None:
        return dhan.option_chain(symbol)
    if symbol == "SENSEX":
        return bse.option_chain()
    return nse.option_chain(symbol)


@app.get("/api/analysis/{symbol}")
def api_analysis(symbol: str):
    try:
        chain = get_chain(symbol)
        return analyze(chain)
    except HTTPException:
        raise
    except Exception as e:
        traceback.print_exc()
        return JSONResponse(status_code=502, content={"error": str(e)})


@app.get("/api/ai/{symbol}")
def api_ai(symbol: str):
    try:
        chain = get_chain(symbol)
        analysis = analyze(chain)
        return {"analysis": deep_ai_analysis(analysis)}
    except Exception as e:
        traceback.print_exc()
        return JSONResponse(status_code=502, content={"error": str(e)})


@app.get("/")
def index():
    return FileResponse(os.path.join(BASE, "static", "dashboard.html"))


app.mount("/static", StaticFiles(directory=os.path.join(BASE, "static")), name="static")


if __name__ == "__main__":
    import uvicorn
    print("\n  LTP Option Chain Monitor  ->  http://127.0.0.1:8000\n")
    uvicorn.run(app, host="127.0.0.1", port=8000)
