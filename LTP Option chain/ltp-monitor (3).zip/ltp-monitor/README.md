# LTP Option Chain Monitor

A local dashboard for NIFTY, BANKNIFTY, FINNIFTY and SENSEX option chains, inspired by volume/OI based "LTP calculator" style analysis: buyer/seller dominance per strike, OI walls (support/resistance), max pain, PCR, a risk meter, seller risk zones (green → red), a rule-engine that proposes trades, and an optional Claude-powered deep-analysis mode.

## Quick start (Windows / Mac / Linux)

```bash
cd ltp-monitor
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:8000 — pick an index tab; data refreshes every 30 seconds.

## AI deep-analysis mode (optional)

Set your Anthropic API key before starting, then click "Run deep analysis":

```bash
# Windows (PowerShell)
$env:ANTHROPIC_API_KEY="sk-ant-..."
# Mac/Linux
export ANTHROPIC_API_KEY="sk-ant-..."
python app.py
```

Without a key, the built-in rule engine still produces bias, market state, risk zones and trade ideas.


## Live data via Dhan (recommended)

1. Log in at web.dhan.co -> My Profile -> **DhanHQ Trading APIs** -> generate an **Access Token**. Make sure the **Data APIs pack** (~Rs 499/month) is active on your account — the option-chain endpoint needs it.
2. Before starting the app, set (Mac/Linux):

```bash
export DHAN_CLIENT_ID="your-client-id"
export DHAN_ACCESS_TOKEN="your-token"
python app.py
```

The app auto-detects the credentials and switches every symbol — NIFTY, BANKNIFTY, FINNIFTY and SENSEX — to Dhan's live feed (fresh every ~12s, within Dhan's 1-request-per-3s limit). Tokens expire (24h on the basic plan), so regenerate and re-export if you see a 401 message.

## Important facts about the data

1. NIFTY / BANKNIFTY / FINNIFTY come from NSE's public option-chain endpoint. It is a snapshot the exchange refreshes roughly every 1–3 minutes — near real-time, not tick-by-tick. The app polls every 30s and reuses browser-style cookies to stay compatible.
2. NSE blocks cloud/datacenter IPs and aggressive polling. Run this from a normal home/office internet connection. If you see a fetch error, wait a minute or restart — the client automatically rebuilds its session.
3. SENSEX trades on BSE, not NSE. The app pulls it from BSE's public API on a best-effort basis; BSE's endpoints change more often than NSE's. If SENSEX fails, use a broker feed (below).
4. For true tick-level real time (what paid LTP-calculator tools use), plug in a broker market-data API — see `broker_adapter.py`. DhanHQ's feed is free with an account; Zerodha Kite Connect is paid. The adapter file documents the exact dict shape to return; then swap one line in `app.py`.

## What the dashboard shows

- Risk meter (0–100): how hostile conditions are for fresh positions (distance from max pain, one-sided PCR, elevated IV).
- Bias & market state: bullish/bearish/rangebound from PCR, max pain, and writer behaviour (short build-up in PEs = bullish support, in CEs = bearish cap).
- OI walls chart: biggest CE OI = resistance, biggest PE OI = support.
- Chain table with risk zones: each cell is tinted green (safe for writers) → amber → red (danger zone); ⚡ marks heavy intraday churn (volume ≫ ΔOI).
- Trade ideas: rule-engine suggestions with entry hint, stoploss and target zones, plus rationale.

## Disclaimer

This is educational decision-support software, not investment advice. Index options are high-risk instruments; always confirm prices on your broker's live terminal and size positions responsibly.
